/**
 * AI Friend Project Launcher
 * 
 * This script helps launch the AI Friend project with proper environment configuration
 * and provides fallback options when needed.
 */

const { spawn, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Configure user interface for input/output
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Open browser to the application URL
function openBrowser(url) {
    console.log(`Opening ${url} in your default browser...`);
    
    // Determine the command based on operating system
    let command;
    switch (process.platform) {
        case 'darwin':  // macOS
            command = `open "${url}"`;
            break;
        case 'win32':   // Windows
            command = `start "" "${url}"`;
            break;
        default:        // Linux and others
            command = `xdg-open "${url}"`;
            break;
    }

    // Execute the command
    exec(command, (error) => {
        if (error) {
            console.error('Failed to open browser automatically. Please open the URL manually:', url);
        }
    });
}

// Check if we have necessary files and dependencies
function checkPrerequisites() {
    console.log('Checking project prerequisites...\n');

    // Check if node_modules exists
    if (!fs.existsSync('./node_modules')) {
        console.log('❌ Node modules not found. Installing dependencies...');
        const npm = spawn('npm', ['install'], { stdio: 'inherit' });
        
        return new Promise((resolve) => {
            npm.on('close', (code) => {
                if (code === 0) {
                    console.log('✅ Dependencies installed successfully.');
                    resolve(true);
                } else {
                    console.error('❌ Failed to install dependencies. Please run npm install manually.');
                    resolve(false);
                }
            });
        });
    }
    
    // Check if .env exists
    if (!fs.existsSync('./.env')) {
        console.log('⚠️ .env file not found. Creating default configuration...');
        const defaultEnv = 
`# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Configuration
MONGODB_URI=${process.env.MONGODB_URI}

# JWT Configuration
JWT_SECRET=${process.env.JWT_SECRET}
JWT_EXPIRES_IN=24h

# Gemini AI Configuration
GEMINI_API_KEY=${process.env.GEMINI_API_KEY}

# CORS Configuration
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5000,http://localhost:8080,http://127.0.0.1:5500,http://localhost:5500

# Security
BCRYPT_SALT_ROUNDS=12`;
        
        fs.writeFileSync('./.env', defaultEnv);
        console.log('✅ Default .env file created.');
    } else {
        console.log('✅ .env file found.');
    }

    return Promise.resolve(true);
}

// Execute a command with proper error handling
function executeCommand(command, args, options = {}) {
    return new Promise((resolve, reject) => {
        try {
            const childProcess = spawn(command, args, options);
            
            childProcess.on('error', (err) => {
                reject(err);
            });
            
            childProcess.on('close', (code) => {
                if (code === 0) {
                    resolve();
                } else {
                    reject(new Error(`Command exited with code ${code}`));
                }
            });
            
            return childProcess;
        } catch (error) {
            reject(error);
        }
    });
}

// Start the backend server
function startServer() {
    console.log('\n🚀 Starting AI Friend server...');
    
    try {
        const server = spawn('node', ['server/server.js'], { stdio: 'inherit' });
        
        server.on('error', (err) => {
            console.error('❌ Failed to start server:', err);
            console.log('Try running the server manually with: npm run server');
        });
        
        return server;
    } catch (error) {
        console.error('❌ Error launching server:', error);
        console.log('Try running the server manually with: npm run server');
        return null;
    }
}

// Check if a command is available
async function isCommandAvailable(command) {
    return new Promise((resolve) => {
        const platform = process.platform;
        const cmd = platform === 'win32' ? 'where' : 'which';
        const args = [command];
        
        const proc = spawn(cmd, args, { stdio: 'ignore' });
        
        proc.on('close', (code) => {
            resolve(code === 0);
        });
        
        proc.on('error', () => {
            resolve(false);
        });
    });
}

// Try to start a direct HTTP server without using npx
async function startDirectHttpServer() {
    console.log('Starting HTTP server using direct Node.js module...');
    
    try {
        // Check if http-server is installed as a dependency
        const httpServerModule = path.join(process.cwd(), 'node_modules', 'http-server');
        
        if (!fs.existsSync(httpServerModule)) {
            console.log('Installing http-server as a dependency...');
            await executeCommand('npm', ['install', '--save', 'http-server']);
        }
        
        // Create a script to run http-server using Node's require
        const script = `
            const httpServer = require('http-server');
            const server = httpServer.createServer({
                root: '.',
                cors: true,
                cache: -1,
                port: 8080,
                host: '0.0.0.0'
            });
            
            // Handle potential errors
            server.server.on('error', (err) => {
                if (err.code === 'EADDRINUSE') {
                    console.error('Port 8080 is already in use. Please close other services using this port.');
                    console.log('You can try accessing the app directly at: http://localhost:8080');
                } else {
                    console.error('HTTP Server error:', err);
                }
            });
            
            // Listen on all interfaces
            server.listen(8080, '0.0.0.0', function() {
                console.log('✅ HTTP server running at http://localhost:8080/');
                console.log('You can now open your browser and navigate to: http://localhost:8080');
            });
        `;
        
        // Write the script to a temporary file
        const scriptPath = path.join(process.cwd(), 'temp-http-server.js');
        fs.writeFileSync(scriptPath, script);
        
        // Run the script
        const server = spawn('node', [scriptPath], { stdio: 'inherit' });
        
        // Clean up the temporary file when the server exits
        server.on('exit', () => {
            try {
                fs.unlinkSync(scriptPath);
            } catch (error) {
                // Ignore cleanup errors
            }
        });
        
        return server;
    } catch (error) {
        console.error('Error starting direct HTTP server:', error);
        return null;
    }
}

// Start a simple native Node.js HTTP server as a last resort
async function startSimpleServer() {
    console.log('Starting simple native Node.js HTTP server...');
    
    try {
        // Create a script to run a simple HTTP server
        const script = `
            const http = require('http');
            const fs = require('fs');
            const path = require('path');
            
            // MIME types for different file extensions
            const mimeTypes = {
                '.html': 'text/html',
                '.css': 'text/css',
                '.js': 'text/javascript',
                '.json': 'application/json',
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.gif': 'image/gif',
                '.svg': 'image/svg+xml',
                '.ico': 'image/x-icon'
            };
            
            // Create a simple HTTP server
            const server = http.createServer((req, res) => {
                console.log(\`Request: \${req.method} \${req.url}\`);
                
                // Normalize the URL and get the file path
                let filePath = path.join(process.cwd(), req.url === '/' ? 'index.html' : req.url);
                
                // Check if the file exists
                fs.access(filePath, fs.constants.F_OK, (err) => {
                    if (err) {
                        // If the file doesn't exist, return 404
                        console.log(\`File not found: \${filePath}\`);
                        res.writeHead(404, { 'Content-Type': 'text/html' });
                        res.end('<h1>404 Not Found</h1>');
                        return;
                    }
                    
                    // If the path is a directory, try to serve index.html
                    fs.stat(filePath, (err, stats) => {
                        if (err) {
                            res.writeHead(500, { 'Content-Type': 'text/html' });
                            res.end('<h1>500 Internal Server Error</h1>');
                            return;
                        }
                        
                        if (stats.isDirectory()) {
                            filePath = path.join(filePath, 'index.html');
                        }
                        
                        // Read the file and serve it
                        fs.readFile(filePath, (err, data) => {
                            if (err) {
                                res.writeHead(500, { 'Content-Type': 'text/html' });
                                res.end('<h1>500 Internal Server Error</h1>');
                                return;
                            }
                            
                            // Determine the content type based on the file extension
                            const ext = path.extname(filePath);
                            const contentType = mimeTypes[ext] || 'application/octet-stream';
                            
                            // Set CORS headers
                            res.writeHead(200, { 
                                'Content-Type': contentType,
                                'Access-Control-Allow-Origin': '*',
                                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                                'Access-Control-Allow-Headers': 'Content-Type'
                            });
                            res.end(data);
                        });
                    });
                });
            });
            
            // Handle EADDRINUSE error
            server.on('error', (err) => {
                if (err.code === 'EADDRINUSE') {
                    console.error('Port 8080 is already in use. Please close any other servers using this port.');
                } else {
                    console.error('Server error:', err);
                }
            });
            
            // Start the server
            server.listen(8080, '0.0.0.0', () => {
                console.log('✅ Simple HTTP server running at http://localhost:8080/');
                console.log('You can now open your browser and navigate to: http://localhost:8080');
            });
        `;
        
        // Write the script to a temporary file
        const scriptPath = path.join(process.cwd(), 'temp-simple-server.js');
        fs.writeFileSync(scriptPath, script);
        
        // Run the script
        const server = spawn('node', [scriptPath], { stdio: 'inherit' });
        
        // Clean up the temporary file when the server exits
        server.on('exit', () => {
            try {
                fs.unlinkSync(scriptPath);
            } catch (error) {
                // Ignore cleanup errors
            }
        });
        
        return server;
    } catch (error) {
        console.error('Error starting simple HTTP server:', error);
        return null;
    }
}

// Start the frontend using any available method
async function startFrontend() {
    console.log('\n🌐 Starting frontend server...');
    
    try {
        // Try direct Node.js HTTP server first (most reliable method)
        try {
            return await startDirectHttpServer();
        } catch (directError) {
            console.log('Direct HTTP server failed, trying simple native server...');
            
            try {
                return await startSimpleServer();
            } catch (simpleError) {
                console.log('Simple native server failed, trying alternative methods...');
            }
        }
        
        // Check if npx is available
        const hasNpx = await isCommandAvailable('npx');
        
        if (hasNpx) {
            console.log('Using npx to start the frontend server...');
            return launchHttpServer('npx');
        } else {
            // Try using http-server directly if installed globally
            const hasHttpServer = await isCommandAvailable('http-server');
            
            if (hasHttpServer) {
                console.log('Using globally installed http-server...');
                return launchHttpServer('http-server', ['.', '-p', '8080', '--cors']);
            } else {
                // Try using node_modules/.bin/http-server if available
                const httpServerPath = path.join('.', 'node_modules', '.bin', 'http-server');
                
                if (fs.existsSync(httpServerPath)) {
                    console.log('Using local http-server from node_modules...');
                    return launchHttpServer(httpServerPath, ['.', '-p', '8080', '--cors']);
                } else {
                    // Install http-server locally as a last resort
                    console.log('Installing http-server locally...');
                    
                    try {
                        await executeCommand('npm', ['install', '--no-save', 'http-server']);
                        
                        // Now try again with the locally installed version
                        if (fs.existsSync(httpServerPath)) {
                            console.log('Using newly installed local http-server...');
                            return launchHttpServer(httpServerPath, ['.', '-p', '8080', '--cors']);
                        }
                    } catch (installError) {
                        throw new Error(`Failed to install http-server: ${installError.message}`);
                    }
                }
            }
        }
        
        throw new Error('Could not find a way to start the frontend server');
    } catch (error) {
        console.error('❌ Error starting frontend server:', error.message);
        console.log('\n🔍 Alternative ways to start the frontend:');
        console.log('1. Run "npm install -g http-server" to install it globally');
        console.log('2. Run "npx http-server . -p 8080 --cors" in a separate terminal');
        console.log('3. Use a different static file server like "serve" or "live-server"');
        console.log('4. Open the index.html file directly in your browser (some features may not work)');
        
        return null;
    }
}

// Launch the HTTP server for the frontend
function launchHttpServer(command, args = ['http-server', '.', '-p', '8080', '--cors']) {
    try {
        const frontend = spawn(command, args, { stdio: 'inherit' });
        
        frontend.on('error', (err) => {
            console.error(`❌ Failed to start frontend server with ${command}:`, err);
        });
        
        return frontend;
    } catch (error) {
        console.error(`❌ Error launching frontend server with ${command}:`, error);
        return null;
    }
}

// Open a file directly without server
function openFileDirectly() {
    console.log('\n⚠️ Using fallback method - opening file directly');
    const indexPath = path.join(process.cwd(), 'index.html');
    
    if (fs.existsSync(indexPath)) {
        const fileUrl = `file://${indexPath}`;
        console.log(`Opening file directly: ${fileUrl}`);
        openBrowser(fileUrl);
        return true;
    } else {
        console.error('❌ Could not find index.html file to open directly');
        return false;
    }
}

// Main function to start everything
async function startProject() {
    console.log('🧠 AI Friend Project Launcher 🧠\n');
    
    const prereqsOk = await checkPrerequisites();
    if (!prereqsOk) {
        console.error('❌ Prerequisites check failed. Please fix the issues and try again.');
        process.exit(1);
    }
    
    rl.question('Start both backend and frontend? (Y/n): ', async (answer) => {
        const startBoth = answer.toLowerCase() !== 'n';
        
        if (startBoth) {
            // Start backend
            const server = startServer();
            
            // Wait a bit before starting frontend
            setTimeout(async () => {
                const frontendServer = await startFrontend();
                
                // Note: These ports might be different if the original ports were in use
                const backendPort = process.env.PORT || 5000;
                console.log('\n✨ AI Friend is now running! ✨');
                console.log(`- Backend: http://localhost:${backendPort}`);
                console.log('- Frontend: http://localhost:8080');
                console.log('\nOpen http://localhost:8080 in your browser to get started.');
                console.log('\nPress Ctrl+C to stop all servers.');
                
                // Ask if the user wants to open the browser automatically
                rl.question('Open in browser now? (Y/n): ', (openBrowserAnswer) => {
                    if (openBrowserAnswer.toLowerCase() !== 'n') {
                        openBrowser('http://localhost:8080');
                        
                        // Set a timer to check if browser was able to connect
                        setTimeout(() => {
                            rl.question('Did the page load successfully? (Y/n): ', (loadedAnswer) => {
                                if (loadedAnswer.toLowerCase() === 'n') {
                                    console.log('Trying alternative approach...');
                                    // Try to open file directly as a fallback
                                    openFileDirectly();
                                }
                            });
                        }, 5000);
                    }
                });
            }, 3000);
        } else {
            rl.question('Which component to start? (1: Backend, 2: Frontend, 3: Open files directly): ', async (component) => {
                if (component === '1') {
                    startServer();
                    console.log('\n✨ AI Friend backend is now running ✨');
                } else if (component === '2') {
                    await startFrontend();
                    console.log('\n✨ AI Friend frontend is now running at http://localhost:8080 ✨');
                    console.log('\nOpen http://localhost:8080 in your browser to get started.');
                    
                    // Ask if the user wants to open the browser automatically
                    rl.question('Open in browser now? (Y/n): ', (openBrowserAnswer) => {
                        if (openBrowserAnswer.toLowerCase() !== 'n') {
                            openBrowser('http://localhost:8080');
                        }
                    });
                } else if (component === '3') {
                    // Open HTML file directly
                    if (openFileDirectly()) {
                        console.log('\n✨ Opening AI Friend directly in browser ✨');
                        console.log('\nNote: Some features may not work without the backend server.');
                    }
                } else {
                    console.log('Invalid option. Exiting.');
                    rl.close();
                    process.exit(0);
                }
                
                console.log('\nPress Ctrl+C to stop the server.');
            });
        }
    });
}

// Handle script termination
process.on('SIGINT', () => {
    console.log('\n👋 Shutting down AI Friend...');
    rl.close();
    process.exit(0);
});

// Start the project
startProject(); 