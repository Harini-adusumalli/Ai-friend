import { api } from './api.js';
import GeminiAI from './gemini-integration.js';
import config from './config.js';
import { showError, showSuccess } from './utils.js';

// Initialize GeminiAI
const geminiAI = new GeminiAI(config.GEMINI_API_KEY);

// DOM Elements
const journalEntry = document.getElementById('journalEntry');
const saveJournalBtn = document.getElementById('saveJournalBtn');
const journalEntries = document.getElementById('journalEntries');
const newTaskInput = document.getElementById('newTask');
const addTaskBtn = document.getElementById('addTaskBtn');
const tasksList = document.getElementById('tasksList');
const aiInsights = document.querySelector('.ai-insights');

// Check authentication and redirect if needed
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Load journal entries with error handling
async function loadJournalEntries() {
    if (!checkAuth()) return;

    try {
        const entries = await api.getJournalEntries();
        journalEntries.innerHTML = ''; // Clear existing entries
        
        entries.forEach(entry => {
            const entryElement = createJournalEntryElement(entry);
            journalEntries.appendChild(entryElement);
        });
    } catch (error) {
        console.error('Error loading journal entries:', error);
        
        if (error.message.includes('Session expired') || error.message.includes('invalid token')) {
            // Clear invalid token and redirect to login
            localStorage.clear();
            window.location.href = 'login.html';
            return;
        }
        
        // Show error message to user
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = 'Failed to load journal entries. Please try refreshing the page.';
        journalEntries.appendChild(errorDiv);
    }
}

// Create journal entry element
function createJournalEntryElement(entry) {
    const div = document.createElement('div');
    div.className = 'journal-entry';
    
    const date = new Date(entry.createdAt).toLocaleDateString();
    const time = new Date(entry.createdAt).toLocaleTimeString();
    
    div.innerHTML = `
                <div class="entry-header">
            <span class="entry-date">${date} ${time}</span>
            <div class="entry-actions">
                <button class="edit-btn" data-id="${entry._id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="delete-btn" data-id="${entry._id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
                </div>
        <div class="entry-content">${entry.content}</div>
        ${entry.aiAnalysis ? `
            <div class="ai-analysis">
                <h4><i class="fas fa-robot"></i> AI Insights</h4>
                <p>${entry.aiAnalysis}</p>
            </div>
        ` : ''}
    `;

    // Add event listeners
    div.querySelector('.edit-btn').addEventListener('click', () => editEntry(entry));
    div.querySelector('.delete-btn').addEventListener('click', () => deleteEntry(entry._id));

    return div;
}

// Update AI task suggestions
async function updateTaskSuggestions() {
    const taskSuggestionsContainer = document.getElementById('taskSuggestions');
    const journalContent = document.getElementById('journalEntry').value;
    
    if (!taskSuggestionsContainer) return;
    
    try {
        // Only proceed if we have journal content
        if (journalContent.trim().length > 20) {
            // Show loading state
            taskSuggestionsContainer.innerHTML = `
                <div class="loading">
                    <div class="loading-spinner"></div>
                    <p>Analyzing your journal entry...</p>
                </div>
            `;
            
            // Try to get AI analysis with error handling
            let analysis;
            try {
                analysis = await geminiAI.analyzeJournalAndSuggestTasks(journalContent);
            } catch (analysisError) {
                console.error('Error getting journal analysis:', analysisError);
                // Force fallback mode if we encounter an error
                geminiAI.fallbackMode = true;
                analysis = await geminiAI.analyzeJournalAndSuggestTasks(journalContent);
            }
            
            // Extract tasks from analysis with error handling
            let tasks;
            try {
                tasks = await geminiAI.extractTasksFromAnalysis(analysis);
            } catch (tasksError) {
                console.error('Error extracting tasks:', tasksError);
                // Use a simple fallback if task extraction fails
                tasks = [
                    "🧘 Take 10 minutes for mindful breathing",
                    "📋 Break down any overwhelming tasks into smaller steps",
                    "🌳 Consider a short walk outside to clear your mind",
                    "🛌 Ensure you're getting enough rest"
                ];
            }
            
            // Update suggestions container
            taskSuggestionsContainer.innerHTML = `
                <div class="task-suggestions-header">
                    <h3>Suggested Tasks</h3>
                    <button id="addAllTasksBtn" class="add-all-btn">
                        <i class="fas fa-plus-circle"></i> Add All
                    </button>
                </div>
                <div class="suggestions-list">
                    ${tasks.map(task => `
                        <div class="task-suggestion-item">
                            <span class="task-suggestion-text">${task}</span>
                            <button class="add-suggestion-btn">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    `).join('')}
                </div>
            `;
            
            // Add event listeners to suggestion buttons
            document.querySelectorAll('.add-suggestion-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const taskText = btn.previousElementSibling.textContent;
                    addTask(taskText);
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fas fa-check"></i>';
                });
            });
            
            // Add all tasks button
            const addAllBtn = document.getElementById('addAllTasksBtn');
            if (addAllBtn) {
                addAllBtn.addEventListener('click', () => {
                    const suggestions = document.querySelectorAll('.task-suggestion-text');
                    suggestions.forEach(suggestion => {
                        addTask(suggestion.textContent);
                    });
                    
                    // Show added state
                    addAllBtn.innerHTML = '<i class="fas fa-check"></i> Added';
                    addAllBtn.disabled = true;
                    
                    document.querySelectorAll('.add-suggestion-btn').forEach(btn => {
                        btn.disabled = true;
                        btn.innerHTML = '<i class="fas fa-check"></i>';
                    });
                });
            }
        } else {
            // Show empty state if no journal content
            taskSuggestionsContainer.innerHTML = `
                <div class="empty-suggestions">
                    <p>Start writing in your journal to get task suggestions</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error updating task suggestions:', error);
        
        // Check for specific errors
        let errorMessage = 'Unable to generate task suggestions at this time.';
        
        if (error.message && (
            error.message.includes('gemini-pro is not found') || 
            error.message.includes('model is not found')
        )) {
            errorMessage = 'The AI model may be outdated or unavailable. We\'re using our built-in suggestions instead.';
            // Force fallback mode to ensure future requests use fallback
            geminiAI.fallbackMode = true;
            
            // Show fallback tasks instead of error
            try {
                const fallbackTasks = [
                    "🧘 Take 10 minutes for mindful breathing",
                    "📋 Break down any overwhelming tasks into smaller steps",
                    "🌳 Consider a short walk outside to clear your mind",
                    "🛌 Ensure you're getting enough rest"
                ];
                
                taskSuggestionsContainer.innerHTML = `
                    <div class="task-suggestions-header">
                        <h3>Suggested Tasks</h3>
                        <button id="addAllTasksBtn" class="add-all-btn">
                            <i class="fas fa-plus-circle"></i> Add All
                        </button>
                    </div>
                    <div class="suggestions-list">
                        ${fallbackTasks.map(task => `
                            <div class="task-suggestion-item">
                                <span class="task-suggestion-text">${task}</span>
                                <button class="add-suggestion-btn">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        `).join('')}
                    </div>
                `;
                
                // Add event listeners to buttons
                document.querySelectorAll('.add-suggestion-btn').forEach(btn => {
                    btn.addEventListener('click', () => {
                        const taskText = btn.previousElementSibling.textContent;
                        addTask(taskText);
                        btn.disabled = true;
                        btn.innerHTML = '<i class="fas fa-check"></i>';
                    });
                });
                
                // Add all tasks button
                const addAllBtn = document.getElementById('addAllTasksBtn');
                if (addAllBtn) {
                    addAllBtn.addEventListener('click', () => {
                        const suggestions = document.querySelectorAll('.task-suggestion-text');
                        suggestions.forEach(suggestion => {
                            addTask(suggestion.textContent);
                        });
                        
                        // Show added state
                        addAllBtn.innerHTML = '<i class="fas fa-check"></i> Added';
                        addAllBtn.disabled = true;
                        
                        document.querySelectorAll('.add-suggestion-btn').forEach(btn => {
                            btn.disabled = true;
                            btn.innerHTML = '<i class="fas fa-check"></i>';
                        });
                    });
                }
                
                return; // Exit early since we've handled the error with fallback content
            } catch (fallbackError) {
                console.error('Error displaying fallback tasks:', fallbackError);
                // Fall through to default error message if fallback fails
            }
        } else if (error.message && error.message.includes('API key')) {
            errorMessage = 'AI features require a valid API key. Please check your configuration.';
        }
        
        taskSuggestionsContainer.innerHTML = `
            <div class="error-suggestions">
                <p>${errorMessage}</p>
                <button id="retryTasksBtn" class="retry-btn">
                    <i class="fas fa-sync-alt"></i> Try Again
                </button>
            </div>
        `;
        
        // Add retry button functionality
        const retryBtn = document.getElementById('retryTasksBtn');
        if (retryBtn) {
            retryBtn.addEventListener('click', updateTaskSuggestions);
        }
    }
}

// Save journal entry
async function saveJournalEntry() {
    if (!checkAuth()) return;
    
    const content = journalEntry.value.trim();

    if (!content) {
        showError('Please write something in your journal');
        return;
    }

    try {
        saveJournalBtn.disabled = true;
        await api.createJournalEntry(content);
        
        // Update AI suggestions with new content
        await updateTaskSuggestions();
        
        // Clear and refresh
        journalEntry.value = '';
        await loadJournalEntries();
        
        showSuccess('Journal entry saved successfully!');
    } catch (error) {
        console.error('Error saving journal entry:', error);
        showError(error.message || 'Failed to save journal entry');
    } finally {
        saveJournalBtn.disabled = false;
    }
}

// Edit journal entry
async function editEntry(entry) {
    if (!checkAuth()) return;

    const newContent = prompt('Edit your entry:', entry.content);
    if (!newContent || newContent === entry.content) return;

    try {
        await api.updateJournalEntry(entry._id, newContent);
        await loadJournalEntries();
    } catch (error) {
        console.error('Error updating journal entry:', error);
        
        if (error.message.includes('Session expired') || error.message.includes('invalid token')) {
            localStorage.clear();
            window.location.href = 'login.html';
            return;
        }
        
        alert('Failed to update journal entry. Please try again.');
    }
}

// Delete journal entry
async function deleteEntry(entryId) {
    if (!checkAuth()) return;
    
    if (!confirm('Are you sure you want to delete this entry?')) return;

    try {
        await api.deleteJournalEntry(entryId);
        await loadJournalEntries();
    } catch (error) {
        console.error('Error deleting journal entry:', error);
        
        if (error.message.includes('Session expired') || error.message.includes('invalid token')) {
            localStorage.clear();
            window.location.href = 'login.html';
            return;
        }
        
        alert('Failed to delete journal entry. Please try again.');
    }
}

// Add task
function addTask(taskText = '') {
    const text = taskText || newTaskInput.value.trim();
    if (!text) return;

    const li = document.createElement('li');
    li.className = 'task-item';
    li.innerHTML = `
        <div class="task-content">
            <input type="checkbox" class="task-checkbox">
            <span class="task-text">${text}</span>
        </div>
        <button class="delete-task-btn">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add event listeners
    const checkbox = li.querySelector('.task-checkbox');
    const deleteBtn = li.querySelector('.delete-task-btn');

    checkbox.addEventListener('change', () => {
        li.classList.toggle('completed', checkbox.checked);
        saveTasksToLocalStorage();
    });

    deleteBtn.addEventListener('click', () => {
        li.remove();
        saveTasksToLocalStorage();
    });

    // Add to list
    tasksList.appendChild(li);
    
    // Clear input if it was manually entered
    if (!taskText) {
        newTaskInput.value = '';
    }

    // Save to localStorage
    saveTasksToLocalStorage();
}

// Add localStorage support for tasks
function saveTasksToLocalStorage() {
    const tasks = Array.from(tasksList.querySelectorAll('li')).map(li => ({
        text: li.querySelector('.task-text').textContent,
        completed: li.querySelector('.task-checkbox').checked
    }));
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasksFromLocalStorage() {
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    tasks.forEach(task => {
        const li = document.createElement('li');
        li.className = 'task-item' + (task.completed ? ' completed' : '');
        li.innerHTML = `
            <div class="task-content">
                <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''}>
                <span class="task-text">${task.text}</span>
            </div>
            <button class="delete-task-btn">
                <i class="fas fa-times"></i>
            </button>
        `;

        // Add event listeners
        const checkbox = li.querySelector('.task-checkbox');
        const deleteBtn = li.querySelector('.delete-task-btn');

        checkbox.addEventListener('change', () => {
            li.classList.toggle('completed', checkbox.checked);
            saveTasksToLocalStorage();
        });

        deleteBtn.addEventListener('click', () => {
            li.remove();
            saveTasksToLocalStorage();
        });

        tasksList.appendChild(li);
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    try {
        if (!checkAuth()) return;
        
        await loadJournalEntries();
        loadTasksFromLocalStorage();
        updateTaskSuggestions();

        // Add event listeners
        saveJournalBtn.addEventListener('click', saveJournalEntry);
        addTaskBtn.addEventListener('click', () => addTask());
        newTaskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addTask();
        });

        // Add real-time suggestions
        let suggestionTimeout;
        journalEntry.addEventListener('input', () => {
            clearTimeout(suggestionTimeout);
            suggestionTimeout = setTimeout(() => {
                updateTaskSuggestions(journalEntry.value.trim());
            }, 1000);
        });
    } catch (error) {
        console.error('Initialization error:', error);
        showError('Failed to initialize journal');
    }
}); 