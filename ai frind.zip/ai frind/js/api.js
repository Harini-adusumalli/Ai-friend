class API {
    constructor() {
        // Add support for both absolute and relative URLs for deployment flexibility
        const protocol = window.location.protocol;
        const hostname = window.location.hostname;
        
        // Try to use the same host as the client when in production
        if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
            this.baseURL = `${protocol}//${hostname}/api`;
            this.clientBasePath = `${protocol}//${hostname}`;
        } else {
            this.baseURL = 'http://localhost:5000/api';
            this.clientBasePath = 'http://localhost:8080';
        }
        
        console.log('API Base URL:', this.baseURL);
        console.log('Client Base Path:', this.clientBasePath);
    }

    redirectToLogin() {
        window.location.href = `${this.clientBasePath}/login.html`;
    }

    async authenticatedRequest(endpoint, options = {}) {
        const token = localStorage.getItem('token');
        if (!token) {
            this.redirectToLogin();
            throw new Error('Authentication required');
        }

        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                ...options,
                headers: {
                    ...options.headers,
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const error = await response.json();
                if (error.clearToken) {
                    localStorage.removeItem('token');
                    localStorage.removeItem('currentUser');
                    this.redirectToLogin();
                }
                throw new Error(error.message || 'Request failed');
            }

            return response.json();
        } catch (error) {
            console.error('API request failed:', error);
            
            // More detailed error handling
            if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
                throw new Error('Cannot connect to the server. Please check your internet connection or try again later.');
            }
            
            throw error;
        }
    }

    // Updated to properly handle conversation history
    async sendMessage(content, conversationHistory = null) {
        if (!content) {
            throw new Error('Message content is required');
        }

        // If no backend is available, use the fallback mode with Gemini directly
        try {
            return this.authenticatedRequest('/chat/message', {
                method: 'POST',
                body: JSON.stringify({ 
                    content,
                    conversationHistory: conversationHistory || [] 
                })
            });
        } catch (error) {
            console.error('Server API call failed, using fallback mode:', error);
            
            // If we have the Gemini integration available, use it as fallback
            if (typeof GeminiAI !== 'undefined') {
                try {
                    // Try to get the Gemini API key from config
                    let apiKey = null;
                    if (typeof geminiConfig !== 'undefined' && geminiConfig.apiKey) {
                        apiKey = geminiConfig.apiKey;
                    }
                    
                    const gemini = new GeminiAI(apiKey);
                    const response = await gemini.generateResponse(content);
                    return { response };
                } catch (geminiError) {
                    console.error('Gemini fallback also failed:', geminiError);
                    return { 
                        response: "I'm sorry, I'm having trouble connecting right now. Please check your internet connection and try again."
                    };
                }
            } else {
                // Final fallback if nothing else works
                return { 
                    response: "I apologize, but I'm currently unavailable. Please try again later."
                };
            }
        }
    }

    // Journal
    createJournalEntry(content, mood) {
        return this.authenticatedRequest('/journal', {
            method: 'POST',
            body: JSON.stringify({ content, mood })
        });
    }
    getJournalEntries() {
        return this.authenticatedRequest('/journal');
    }
    updateJournalEntry(id, content, mood) {
        return this.authenticatedRequest(`/journal/${id}`, {
            method: 'PATCH',
            body: JSON.stringify({ content, mood })
        });
    }
    deleteJournalEntry(id) {
        return this.authenticatedRequest(`/journal/${id}`, {
            method: 'DELETE'
        });
    }

    // Mood
    async recordMood(mood, value, notes = '') {
        return this.authenticatedRequest('/moods/add', {
            method: 'POST',
            body: JSON.stringify({ mood, value, notes })
        });
    }

    // Get mood history
    async getMoodHistory() {
        return this.authenticatedRequest('/moods/history');
    }

    // Get mood stats
    async getMoodStats() {
        return this.authenticatedRequest('/moods/stats');
    }

    async deleteMoodEntry(id) {
        return this.authenticatedRequest(`/moods/${id}`, {
            method: 'DELETE'
        });
    }
}

export const api = new API(); 