import { api } from './api.js';  // Add this import

// DOM Elements
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const chatBox = document.getElementById('chat-messages');

// Conversation history
let conversationHistory = [];

// Check authentication
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Initialize chat
function initChat() {
    if (!checkAuth()) return;
    setupEventListeners();
    showWelcomeMessage();
}

// Show welcome message
function showWelcomeMessage() {
    appendMessage('assistant', 'Hello! I\'m your AI friend. How can I help you today?');
}

// Get AI response
async function getAIResponse(message) {
    try {
        const response = await api.sendMessage(message);
        return response.response;
    } catch (error) {
        console.error('Error getting AI response:', error);
        // Check for specific error types
        if (error.message && error.message.includes('Authentication required')) {
            // Auth error - redirect to login
            window.location.href = 'login.html';
            throw new Error('Please log in to continue.');
        } else if (!navigator.onLine) {
            throw new Error('Network connection unavailable. Please check your internet connection.');
        } else {
            throw new Error('Unable to get AI response. Please try again later.');
        }
    }
}

// Send message
async function sendMessage() {
    const content = messageInput.value.trim();
    if (!content) return;

    try {
        // Show user message immediately
        appendMessage('user', content);
        messageInput.value = '';
        
        // Show typing indicator
        const typingIndicator = showTypingIndicator();

        try {
            // Get AI response with timeout
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Request timed out')), 15000)
            );
            const response = await Promise.race([
                getAIResponse(content),
                timeoutPromise
            ]);
            
            // Remove typing indicator
            typingIndicator.remove();

            // Show AI response
            if (response) {
                appendMessage('assistant', response);
            } else {
                throw new Error('No response received');
            }
        } catch (error) {
            console.error('Chat error:', error);
            
            // Remove typing indicator if it exists
            typingIndicator.remove();

            // Show appropriate error message
            if (error.message === 'Request timed out') {
                showErrorMessage("The request is taking too long. The server might be busy. Please try again later.");
            } else if (error.name === 'NetworkError' || !navigator.onLine) {
                showErrorMessage("I'm having trouble connecting to the network. Please check your internet connection and try again.");
            } else if (error.response?.status === 429) {
                showErrorMessage("I'm receiving too many requests right now. Please wait a moment before trying again.");
            } else {
                showErrorMessage("I apologize, but I'm having trouble processing your message. Our servers may be experiencing issues. Please try again later.");
            }
        }
    } catch (error) {
        console.error('Unexpected error:', error);
        showErrorMessage("An unexpected error occurred. Please refresh the page and try again.");
    } finally {
        scrollToBottom();
    }
}

// Show typing indicator
function showTypingIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'message assistant-message typing';
    indicator.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    chatMessages.appendChild(indicator);
    scrollToBottom();
    return indicator;
}

// Append message to chat
function appendMessage(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}-message`;
    
    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    avatar.innerHTML = role === 'user' ? '👤' : '🤖';
    
    const textDiv = document.createElement('div');
    textDiv.className = 'message-text';
    textDiv.textContent = content;
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(textDiv);
    chatMessages.appendChild(messageDiv);
}

// Show error message
function showErrorMessage(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'message error-message';
    errorDiv.textContent = message;
    chatMessages.appendChild(errorDiv);
}

// Auto-resize input
function autoResizeInput() {
    messageInput.style.height = 'auto';
    messageInput.style.height = messageInput.scrollHeight + 'px';
}

// Scroll to bottom of chat
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Setup event listeners
function setupEventListeners() {
    sendButton.addEventListener('click', sendMessage);
    
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    messageInput.addEventListener('input', autoResizeInput);

    // Handle logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('token');
            window.location.href = 'login.html';
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initChat);

function startConversation() {
    setTimeout(async () => {
        try {
            const response = await getAIResponse("Hi! How are you feeling today?");
            displayMessage(response, 'assistant');
        } catch (error) {
            console.error('Error starting conversation:', error);
            displayMessage(
                "I'm having trouble connecting right now. Please try refreshing the page.", 
                'assistant'
            );
        }
    }, 1000);
} 