// Dark mode functionality
export function initializeDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        if (theme === 'dark') {
            document.documentElement.classList.add('dark-mode');
        } else {
            document.documentElement.classList.remove('dark-mode');
        }
    }

    // Initialize theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else if (prefersDarkScheme.matches) {
        setTheme('dark');
    }

    // Toggle theme
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            setTheme(currentTheme === 'dark' ? 'light' : 'dark');
        });
    }

    // Listen for system theme changes
    prefersDarkScheme.addEventListener('change', (e) => {
        setTheme(e.matches ? 'dark' : 'light');
    });
}

// Speech functionality
export function initializeSpeech() {
    const toggleSpeechBtn = document.getElementById('toggleSpeech');
    let speechEnabled = localStorage.getItem('speechEnabled') === 'true';

    function updateSpeechButton() {
        if (toggleSpeechBtn) {
            toggleSpeechBtn.classList.toggle('muted', !speechEnabled);
        }
    }

    function toggleSpeech() {
        speechEnabled = !speechEnabled;
        localStorage.setItem('speechEnabled', speechEnabled);
        updateSpeechButton();
        
        if (!speechEnabled && window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
    }

    if (toggleSpeechBtn) {
        updateSpeechButton();
        toggleSpeechBtn.addEventListener('click', toggleSpeech);
    }

    return {
        isSpeechEnabled: () => speechEnabled,
        speak: (text) => {
            if (speechEnabled && window.speechSynthesis) {
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.rate = 1.0;
                utterance.pitch = 1.0;
                utterance.volume = 1.0;
                window.speechSynthesis.speak(utterance);
            }
        }
    };
} 