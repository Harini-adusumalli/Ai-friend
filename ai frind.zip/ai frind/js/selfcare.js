import { api } from './api.js';
import GeminiAI from './gemini-integration.js';
import config from './config.js';
import { showError, showSuccess } from './utils.js';

// Initialize GeminiAI
const geminiAI = new GeminiAI(config.GEMINI_API_KEY);

// DOM Elements
const wellnessSections = {
    emotional: document.querySelector('#emotional-wellness'),
    physical: document.querySelector('#physical-wellness'),
    mental: document.querySelector('#mental-wellness'),
    social: document.querySelector('#social-wellness')
};
const loadingMessage = document.querySelector('.analyzing-message');
const challengeContainer = document.querySelector('.challenge-container');
const challengeSteps = document.querySelector('.challenge-steps');
const newChallengeBtn = document.getElementById('newChallengeBtn');
const completeAllBtn = document.getElementById('completeAllBtn');

// Track challenge state
let currentChallenge = null;

// Add this near the top with other constants
const categories = {
    emotional: { title: 'Emotional Wellness', emoji: '🫂' },
    physical: { title: 'Physical Wellness', emoji: '💪' },
    mental: { title: 'Mental Wellness', emoji: '🧠' },
    social: { title: 'Social Wellness', emoji: '👥' }
};

// Generate wellness recommendations
async function generateWellnessPlans() {
    try {
        // Check authentication first
        const token = localStorage.getItem('token');
        if (!token) {
            console.log('No authentication token found');
            window.location.href = 'login.html';
                return;
            }

        // Show loading message
        if (loadingMessage) {
            loadingMessage.style.display = 'block';
            console.log('Loading message displayed');
        }

        // Get recent journal entries with error handling
        console.log('Fetching journal entries...');
        const entries = await api.getJournalEntries();
        console.log('Journal entries received:', entries);
        
        if (!entries || entries.length === 0) {
            console.log('No journal entries found');
            Object.values(wellnessSections).forEach(section => {
                if (section) {
                    section.innerHTML = `
                        <h3>Write in your journal to get personalized recommendations</h3>
                        <div class="wellness-content">
                            <p>Your recommendations will appear here after you write some journal entries.</p>
                        </div>
                    `;
                }
            });
            if (loadingMessage) {
                loadingMessage.style.display = 'none';
            }
            return;
        }

        // Get AI recommendations with detailed error handling
        console.log('Preparing journal entries for AI analysis...');
        const recentEntries = entries.slice(0, 5).map(e => e.content).join('\n');
        console.log('Calling Gemini API...');
        
        const aiResponse = await geminiAI.analyzeSelfCareNeeds(recentEntries);
        console.log('AI Response received:', aiResponse);

        if (!aiResponse) {
            throw new Error('No response received from AI');
        }

        // Process recommendations
        const sections = aiResponse.split(/🫂|💪|🧠|👥/).filter(Boolean);
        console.log('Processed sections:', sections);

        if (sections.length === 0) {
            throw new Error('Could not parse AI recommendations');
        }

        // Update UI with recommendations
        Object.entries(wellnessSections).forEach(([key, section], index) => {
            if (!section || !sections[index]) {
                console.log(`Missing section or recommendations for ${key}`);
                return;
            }

            const recommendations = sections[index]
                .split('\n')
                .filter(line => line.trim() && !line.includes('Wellness'))
                .map(line => line.trim());

            console.log(`Recommendations for ${key}:`, recommendations);

            // Use the matching category info
            section.innerHTML = `
                <li class="recommendation-category">
                    ${recommendations.map(rec => `
                        <li class="recommendation-item">
                            <i class="fas fa-check"></i>
                            <span>${rec}</span>
                        </li>
                    `).join('')}
                </li>
            `;
        });

    } catch (error) {
        console.error('Error in generateWellnessPlans:', error);
        
        // Show detailed error message
        Object.values(wellnessSections).forEach(section => {
            if (section) {
                section.innerHTML = `
                    <h3>Unable to Load Recommendations</h3>
                    <div class="wellness-content">
                        <p class="error-message">Error: ${error.message}</p>
                        <p>Please try refreshing the page or writing more journal entries.</p>
                    </div>
                `;
            }
        });
        showError('Failed to generate wellness recommendations: ' + error.message);
    } finally {
        if (loadingMessage) {
            loadingMessage.style.display = 'none';
        }
    }
}

// Add a retry mechanism
let retryCount = 0;
const maxRetries = 3;

async function initializeWithRetry() {
    try {
        await generateWellnessPlans();
    } catch (error) {
        console.error(`Attempt ${retryCount + 1} failed:`, error);
        
        // Handle specific errors
        if (error.message && error.message.includes('gemini-pro is not found')) {
            console.warn('The AI model "gemini-pro" is outdated. Using fallback mode instead.');
            // Force fallback mode for the geminiAI instance
            geminiAI.fallbackMode = true;
            await generateWellnessPlans();
            return;
        }
        
        if (retryCount < maxRetries) {
            retryCount++;
            console.log(`Retrying... Attempt ${retryCount + 1}`);
            setTimeout(initializeWithRetry, 2000); // Wait 2 seconds before retrying
        } else {
            console.error('Max retries reached');
            showError('Unable to load recommendations after multiple attempts');
            
            // Show fallback content
            const wellnessPlans = document.getElementById('wellnessPlans');
            if (wellnessPlans) {
                wellnessPlans.innerHTML = `
                    <div class="error-message">
                        <p>Unable to generate wellness plans. The AI service is currently experiencing issues.</p>
                        <button onclick="location.reload()" class="retry-btn">
                            <i class="fas fa-sync-alt"></i> Refresh Page
                        </button>
                    </div>
                `;
            }
        }
    }
}

// Generate new challenge
async function generateNewChallenge() {
    const challengeSteps = document.getElementById('challengeSteps');
    if (!challengeSteps) return;
    
    try {
        // Show loading state
        challengeSteps.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <p>Creating your personalized challenge...</p>
            </div>
        `;

        // Get recent moods and previous challenges
        const recentMoods = localStorage.getItem('moods') ? 
            JSON.parse(localStorage.getItem('moods')).slice(-3).map(m => m.mood).join(', ') : 
            'neutral';

        const previousChallenges = localStorage.getItem('completedChallenges') ?
            JSON.parse(localStorage.getItem('completedChallenges')).join(', ') :
            'none';

        // Generate challenge with AI
        const challengeContent = await geminiAI.generateDailyChallenge(recentMoods, previousChallenges);

        // Parse challenge content
        const lines = challengeContent.split('\n').filter(line => line.trim());
        const title = lines[0];
        const steps = lines.filter(line => /^\d+\./.test(line.trim()));

        // Handle empty results
        if (!steps.length) {
            throw new Error('Failed to generate valid challenge steps');
        }

        // Render challenge
        challengeSteps.innerHTML = `
            <div class="challenge-header">
                <h3>${title}</h3>
                <p class="challenge-intro">${lines[1] || 'Complete these steps for your daily self-care routine!'}</p>
            </div>
            ${steps.map(step => `
                <div class="challenge-step-item">
                    <input type="checkbox" class="step-checkbox">
                    <span class="step-text">${step}</span>
                    <button class="step-delete">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `).join('')}
            <div class="challenge-footer">
                <p>${lines[lines.length - 1] || 'You got this!'}</p>
            </div>
        `;

        // Add event listeners to checkboxes
        challengeSteps.querySelectorAll('.step-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                checkbox.closest('.challenge-step-item').classList.toggle('completed', checkbox.checked);
                updateChallengeProgress();
            });
        });

        // Add event listeners to delete buttons
        challengeSteps.querySelectorAll('.step-delete').forEach(deleteBtn => {
            if (deleteBtn) {
                deleteBtn.addEventListener('click', () => {
                    deleteBtn.closest('.challenge-step-item').remove();
                    updateChallengeProgress();
                });
            }
        });

        // Save current challenge
        currentChallenge = {
            title,
            steps: steps.map(step => step.replace(/^\d+\.\s+/, '')),
            timestamp: Date.now()
        };
        localStorage.setItem('currentChallenge', JSON.stringify(currentChallenge));

        updateChallengeProgress();
        showSuccess('New challenge generated!');
    } catch (error) {
        console.error('Error generating challenge:', error);
        
        // Check for specific errors
        let errorMessage = 'Unable to generate challenge. Please try again.';
        
        if (error.message && error.message.includes('gemini-pro is not found')) {
            errorMessage = 'The AI model has been updated. Please refresh the page.';
            // Force fallback mode
            geminiAI.fallbackMode = true;
        } else if (error.message && error.message.includes('API key')) {
            errorMessage = 'AI features require a valid API key.';
        }
        
        challengeSteps.innerHTML = `
            <div class="error-message">
                <p>${errorMessage}</p>
                <button onclick="generateNewChallenge()" class="retry-btn">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>
        `;
        showError('Failed to generate challenge: ' + error.message);
    }
}

// Update challenge progress
function updateChallengeProgress() {
    const steps = challengeSteps.querySelectorAll('.challenge-step-item');
    const completedSteps = challengeSteps.querySelectorAll('.challenge-step-item.completed');
    
    if (steps.length === 0) return;

    const progress = (completedSteps.length / steps.length) * 100;
    
    // Update complete all button state
    if (completeAllBtn) {
        completeAllBtn.disabled = completedSteps.length === steps.length;
    }
}

// Complete all steps
function completeAllSteps() {
    const uncheckedSteps = challengeSteps.querySelectorAll('.challenge-step-item:not(.completed)');
    uncheckedSteps.forEach(step => {
        const checkbox = step.querySelector('.step-checkbox');
        checkbox.checked = true;
        step.classList.add('completed');
    });
    updateChallengeProgress();
}

// Update initialization
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('Initializing self-care page...');
        
        // Load saved challenge first
        const savedChallenge = localStorage.getItem('currentChallenge');
        if (savedChallenge) {
            const { title, steps, timestamp } = JSON.parse(savedChallenge);
            const isToday = new Date(timestamp).toDateString() === new Date().toDateString();
            
            if (isToday && steps.length > 0) {
                challengeSteps.innerHTML = `
                    <div class="challenge-header">
                        <h3>${title}</h3>
                    </div>
                    ${steps.map(step => `
                        <div class="challenge-step-item">
                            <input type="checkbox" class="step-checkbox">
                            <span class="step-text">${step}</span>
                            <button class="step-delete">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    `).join('')}
                `;
            } else {
                // Generate new challenge if saved one is old
                await generateNewChallenge();
            }
        } else {
            await generateNewChallenge();
        }

        await initializeWithRetry(); // For wellness plans

        // Add event listeners
        if (newChallengeBtn) {
            newChallengeBtn.addEventListener('click', generateNewChallenge);
        }
        if (completeAllBtn) {
            completeAllBtn.addEventListener('click', completeAllSteps);
        }
    } catch (error) {
        console.error('Initialization error:', error);
        showError('Failed to initialize self-care page');
    }
}); 