import { api } from './api.js';
import { initializeDarkMode } from './features.js';
import { showError, showSuccess, getMoodEmoji } from './utils.js';
import GeminiAI from './gemini-integration.js';
import { MoodTracker } from './mood-tracker-chart.js';
import config from './config.js';

// DOM Elements
const moodButtons = document.querySelectorAll('.mood-btn');
const moodNotes = document.getElementById('moodNotes');
const moodHistory = document.getElementById('moodHistory');
const aiInsights = document.getElementById('aiInsights');
const saveMoodBtn = document.getElementById('saveMoodBtn');
const moodEntries = document.getElementById('moodEntries');
const weeklyAverage = document.getElementById('weeklyAverage');
const commonMood = document.getElementById('commonMood');
const totalEntries = document.getElementById('totalEntries');
const moodChart = document.getElementById('moodChart');
let selectedMoodValue = null;
let chartInstance = null;

// Initialize GeminiAI
const geminiAI = new GeminiAI(config.GEMINI_API_KEY);

// Initialize mood chart
function initializeMoodChart() {
    const canvas = document.getElementById('moodChart');
    if (!canvas || !canvas.getContext) {
        console.error('Canvas element not found or not supported');
        return;
    }

    // Ensure proper canvas setup
    canvas.style.width = '100%';
    canvas.style.height = '300px'; // Or your preferred height
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Destroy existing chart if it exists
    if (chartInstance) {
        chartInstance.destroy();
        chartInstance = null;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('Could not get canvas context');
        return;
    }

    try {
        chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Mood Level',
                    data: [],
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 5,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error initializing chart:', error);
    }
}

// Handle mood selection
function handleMoodSelection(button) {
    moodButtons.forEach(btn => btn.classList.remove('selected'));
    button.classList.add('selected');
    selectedMoodValue = parseInt(button.dataset.value);
    
    if (saveMoodBtn) {
        saveMoodBtn.disabled = false;
    }
}

// Check authentication before any operation
async function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        api.redirectToLogin();
        return false;
    }
    return true;
}

// Save mood entry
async function saveMoodEntry() {
    try {
        const moodInput = document.querySelector('.mood-btn.selected');
        const notesInput = document.getElementById('moodNotes');
        
        if (!moodInput) {
            showError('Please select a mood');
            return;
        }

        const moodValue = parseInt(moodInput.dataset.value);
        const moodType = moodInput.dataset.mood;
        const notes = notesInput ? notesInput.value.trim() : '';

        await api.recordMood(moodType, moodValue, notes);
        
        // Clear form
        moodInput.classList.remove('selected');
        if (notesInput) notesInput.value = '';
        if (saveMoodBtn) saveMoodBtn.disabled = true;
        
        // Refresh data including AI insights
        await loadMoodHistory();
        
        showSuccess('Mood recorded successfully!');
    } catch (error) {
        console.error('Error saving mood:', error);
        showError(error.message || 'Failed to save mood');
    }
}

// Load mood history
async function loadMoodHistory() {
    try {
        const moods = await api.getMoodHistory();
        
        if (moods.length > 0) {
            updateMoodChart(moods);
            updateMoodEntries(moods);
            updateStats(moods);
            await updateAIInsights(moods);
        } else {
            showEmptyState();
        }
    } catch (error) {
        console.error('Error loading mood history:', error);
        showError('Failed to load mood data. Please try again.');
        showEmptyState();
    }
}

// Update mood chart
function updateMoodChart(moods) {
    if (!chartInstance) {
        initializeMoodChart();
    }

    if (!chartInstance) {
        console.error('Chart initialization failed');
        return;
    }

    try {
        const data = moods.map(mood => ({
            x: new Date(mood.createdAt).toLocaleDateString(),
            y: mood.value
        }));

        chartInstance.data.datasets[0].data = data;
        chartInstance.data.labels = data.map(d => d.x);
        chartInstance.update('none'); // Use 'none' for better performance
    } catch (error) {
        console.error('Error updating chart:', error);
    }
}

// Update mood entries
function updateMoodEntries(moods) {
    if (!moodEntries) return;

    moodEntries.innerHTML = '<h2>Your Mood History</h2>';
    
    if (moods.length === 0) {
        moodEntries.innerHTML += `
            <p class="no-entries">No mood entries yet</p>
        `;
        return;
    }

    const entriesContainer = document.createElement('div');
    entriesContainer.className = 'mood-entries-list';
    
    moods.forEach(mood => {
        const entry = document.createElement('div');
        entry.className = 'mood-entry';
        
        const date = new Date(mood.createdAt).toLocaleDateString();
        const time = new Date(mood.createdAt).toLocaleTimeString();
        
        entry.innerHTML = `
            <div class="mood-entry-header">
                <span class="mood-date">${date} ${time}</span>
                <span class="mood-emoji">${getMoodEmoji(mood.value)}</span>
            </div>
            <div class="mood-entry-content">
                <strong>${mood.mood.toUpperCase()}</strong>
                ${mood.notes ? `<p class="mood-notes">${mood.notes}</p>` : ''}
            </div>
        `;
        
        entriesContainer.appendChild(entry);
    });
    
    moodEntries.appendChild(entriesContainer);
}

// Update AI Insights
async function updateAIInsights(moods) {
    const aiInsights = document.querySelector('.ai-insights');
    if (!aiInsights || !moods.length) return;

    try {
        // Show loading state
        aiInsights.innerHTML = `
            <div class="insights-content">
                <p>Generating insights...</p>
                <div class="loading-spinner"></div>
            </div>
        `;
        
        // Get the latest mood
        const latestMood = moods[moods.length - 1];
        
        // Try to get AI analysis with error handling
        let analysis;
        try {
            // Get AI analysis
            analysis = await geminiAI.analyzeMoodAndSuggest(
                latestMood.mood,
                latestMood.notes
            );
        } catch (analysisError) {
            console.error('Error getting mood analysis:', analysisError);
            // Force fallback mode and try again
            geminiAI.fallbackMode = true;
            analysis = await geminiAI.analyzeMoodAndSuggest(
                latestMood.mood,
                latestMood.notes
            );
        }

        // Update the insights container
        aiInsights.innerHTML = `
            <div class="insights-content">
                ${analysis}
            </div>
        `;
    } catch (error) {
        console.error('Error updating AI insights:', error);
        
        // Provide a helpful error message based on the error type
        let errorMessage = 'Unable to generate insights at this time. Please try again later.';
        let useFallback = false;
        
        if (error.message && (
            error.message.includes('gemini-pro is not found') || 
            error.message.includes('model is not found') ||
            error.message.includes('404')
        )) {
            errorMessage = 'The AI model may be outdated or unavailable. Using our built-in insights instead.';
            useFallback = true;
        } else if (error.message && error.message.includes('API key')) {
            errorMessage = 'AI features require a valid API key. Please check your configuration.';
        }
        
        if (useFallback) {
            // Force fallback mode
            geminiAI.fallbackMode = true;
            
            try {
                // Get a fallback response directly
                const latestMood = moods[moods.length - 1];
                const fallbackAnalysis = geminiAI.generateFallbackResponse(
                    `analyze this mood data: ${latestMood.mood}, notes: ${latestMood.notes || ''}`
                );
                
                aiInsights.innerHTML = `
                    <div class="insights-content">
                        ${fallbackAnalysis}
                    </div>
                `;
                return;
            } catch (fallbackError) {
                console.error('Error generating fallback insights:', fallbackError);
                // Continue to error message if fallback fails
            }
        }
        
        aiInsights.innerHTML = `
            <div class="insights-content">
                <p>${errorMessage}</p>
                <button id="refreshInsightsBtn" class="btn-small">
                    <i class="fas fa-sync-alt"></i> Try Again
                </button>
            </div>
        `;
        
        // Add event listener to the refresh button
        const refreshBtn = document.getElementById('refreshInsightsBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => updateAIInsights(moods));
        }
    }
}

// Update stats with null checks
function updateStats(moods) {
    if (!moods || !Array.isArray(moods) || moods.length === 0) {
        // Handle empty state
        if (weeklyAverage) weeklyAverage.textContent = 'N/A';
        if (commonMood) commonMood.textContent = 'N/A';
        if (totalEntries) totalEntries.textContent = '0';
        return;
    }

    // Calculate weekly average
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const weeklyMoods = moods.filter(mood => 
        new Date(mood.createdAt) > oneWeekAgo
    );

    const weeklySum = weeklyMoods.reduce((sum, mood) => sum + mood.value, 0);
    const weeklyAvg = weeklyMoods.length > 0 ? weeklySum / weeklyMoods.length : 0;

    // Find most common mood
    const moodCounts = moods.reduce((counts, mood) => {
        counts[mood.mood] = (counts[mood.mood] || 0) + 1;
        return counts;
    }, {});

    const mostCommonMood = Object.entries(moodCounts)
        .sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    // Update DOM
    if (weeklyAverage) {
        weeklyAverage.textContent = weeklyAvg.toFixed(1);
    }
    if (commonMood) {
        commonMood.textContent = mostCommonMood;
    }
    if (totalEntries) {
        totalEntries.textContent = moods.length.toString();
    }
}

// Add empty state handler
function showEmptyState() {
    const elements = {
        weeklyAverage: document.getElementById('weeklyAverage'),
        commonMood: document.getElementById('commonMood'),
        totalEntries: document.getElementById('totalEntries'),
        moodEntries: document.getElementById('moodEntries')
    };

    // Update stats to show N/A
    if (elements.weeklyAverage) elements.weeklyAverage.textContent = 'N/A';
    if (elements.commonMood) elements.commonMood.textContent = 'N/A';
    if (elements.totalEntries) elements.totalEntries.textContent = '0';

    // Show empty state message
    if (elements.moodEntries) {
        elements.moodEntries.innerHTML = `
            <div class="empty-state">
                <p>No mood entries yet. Start tracking your moods!</p>
            </div>
        `;
    }
}

// Event listeners
moodButtons.forEach(btn => {
    btn.addEventListener('click', () => handleMoodSelection(btn));
});

if (saveMoodBtn) {
    saveMoodBtn.addEventListener('click', saveMoodEntry);
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Wait for DOM to be fully loaded
        await new Promise(resolve => setTimeout(resolve, 100));
        
        if (!await checkAuth()) return;
        
        initializeDarkMode();
        await loadMoodHistory();
        
        if (saveMoodBtn) {
            saveMoodBtn.disabled = true;
        }
    } catch (error) {
        console.error('Initialization error:', error);
        showError('Failed to initialize mood tracker');
    }
});

// Add resize handler for chart responsiveness
window.addEventListener('resize', () => {
    if (chartInstance) {
        const canvas = document.getElementById('moodChart');
        if (canvas) {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
            chartInstance.resize();
        }
    }
}); 