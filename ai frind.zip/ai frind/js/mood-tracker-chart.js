import { api } from './api.js';

export class MoodTracker {
    // ... MoodTracker class implementation from before
}

// Initialize MoodTracker only once
let moodTrackerInstance = null;

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    const chartElement = document.getElementById('moodChart');
    if (chartElement && !moodTrackerInstance) {
        // Clean up any existing chart instances
        const existingChart = Chart.getChart(chartElement);
        if (existingChart) {
            existingChart.destroy();
        }
        
        // Create new instance
        moodTrackerInstance = new MoodTracker();
    }
}); 