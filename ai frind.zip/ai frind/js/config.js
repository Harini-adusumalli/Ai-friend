const config = {
    API_BASE_URL: 'http://localhost:5000/api',
    GEMINI_API_KEY: 'AIzaSyAutbg39jUvF0Pq5wsWSVSMr_yZAQzH-dU',
    DEFAULT_AI_NAME: 'Friend',
    MOOD_EMOJIS: {
        great: '😊',
        good: '🙂',
        okay: '😐',
        bad: '😔',
        awful: '😢'
    },
    CRISIS_HOTLINE: '1-800-273-8255',
    MAX_MESSAGE_LENGTH: 500,
    TYPING_SPEED: 50,
    SPEECH_SETTINGS: {
        rate: 1.0,
        pitch: 1.0,
        volume: 1.0
    }
};

export default config; 