// Import the API utilities
import { api } from './js/api.js';

// Get DOM elements
const chatBox = document.getElementById('chatBox');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const micBtn = document.getElementById('micBtn');
const suggestionChips = document.querySelectorAll('.suggestion-chip');
const moodButtons = document.querySelectorAll('.mood-btn');
const resourceButtons = document.querySelectorAll('.resource-btn');
const toggleSpeechBtn = document.getElementById('toggleSpeech');
const darkModeToggle = document.getElementById('darkModeToggle');

// Chat state
let conversationStarted = false;
let userMood = null;
let speechEnabled = localStorage.getItem('speechEnabled') === 'true'; // Get saved preference

// Update toggle button state based on saved preference
if (toggleSpeechBtn) {
    toggleSpeechBtn.classList.toggle('muted', !speechEnabled);
}

// Initialize conversation history with safe defaults
let conversationHistory = [];

// Initialize user data safely
function initializeUser() {
    try {
        // Get user info safely with fallback
        const currentUserData = localStorage.getItem('currentUser');
        
        if (!currentUserData) {
            console.warn('No user data found. Consider logging in for personalized experience.');
            return {
                firstName: 'Guest',
                age: '30',
                id: 'guest-' + Date.now()
            };
        }
        
        const currentUser = JSON.parse(currentUserData);
        
        // Check for valid user data
        if (!currentUser || !currentUser.firstName) {
            console.warn('Invalid user data found. Using default values.');
            return {
                firstName: 'Guest',
                age: '30',
                id: 'guest-' + Date.now()
            };
        }
        
        return currentUser;
    } catch (error) {
        console.error('Error parsing user data:', error);
        return {
            firstName: 'Guest',
            age: '30',
            id: 'guest-' + Date.now()
        };
    }
}

// Get user info safely
const currentUser = initializeUser();

// Initialize conversation history with system prompt
function initializeConversation() {
    // Store conversation history
    conversationHistory = [
        {
            role: "model",
            parts: [{
                text: `You are a supportive and empathetic AI companion named ${localStorage.getItem('aiName') || 'Friend'}. 
                You're talking to ${currentUser.firstName}, who is ${currentUser.age} years old.
                Always maintain a professional, caring, and non-judgmental tone.
                Never provide medical advice or diagnosis.
                If the user expresses serious mental health concerns or thoughts of self-harm,
                always encourage them to seek professional help and provide crisis hotline information.
                Start by asking how they're feeling today.`
            }]
        }
    ];
}

// Initialize the conversation history
initializeConversation();

// Helper function to add messages to the chat
function addMessage(message, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
    messageDiv.textContent = message;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;

    // Speak the message if it's from the bot and speech is enabled
    if (!isUser && speechEnabled) {
        speakText(message);
    }
}

// Typing indicator
function showTypingIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'message bot-message typing-indicator';
    indicator.textContent = 'Thinking...';
    chatBox.appendChild(indicator);
    chatBox.scrollTop = chatBox.scrollHeight;
    return indicator;
}

// Function to call AI API
async function getAIResponse(userMessage) {
    try {
        // Check user's authentication status
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (!currentUser || !currentUser.id) {
            console.warn('User not authenticated, using limited functionality');
            // Still proceed with conversation, but note the limitation
        }

        // Add user message to history
        conversationHistory.push({
            role: "user",
            parts: [{ text: userMessage }]
        });

        let response;
        try {
            // Try using the server API first (which handles authentication)
            response = await api.sendMessage(userMessage, conversationHistory);
        } catch (serverError) {
            console.error('Server API failed:', serverError);
            
            // If server call fails, try direct Gemini API call as fallback
            try {
                // Check if we have the Gemini integration and config
                if (typeof GeminiAI !== 'undefined' && typeof geminiConfig !== 'undefined') {
                    const gemini = new GeminiAI(geminiConfig.apiKey);
                    const geminiResponse = await gemini.generateResponse(userMessage, conversationHistory);
                    response = { response: geminiResponse };
                } else {
                    throw new Error('Gemini integration not available');
                }
            } catch (geminiError) {
                console.error('Gemini API also failed:', geminiError);
                // Provide a fallback response when everything fails
                response = { 
                    response: "I'm sorry, I'm having trouble connecting right now. Please check your internet connection or try again later."
                };
            }
        }
        
        // Add AI response to history
        conversationHistory.push({
            role: "model",
            parts: [{ text: response.response }]
        });
        
        // Limit conversation history to prevent token overflow
        if (conversationHistory.length > 20) {
            // Keep the system prompt and trim the oldest messages
            const systemPrompt = conversationHistory[0];
            conversationHistory = [
                systemPrompt,
                ...conversationHistory.slice(-19)  // Keep last 19 messages
            ];
        }
        
        return response.response;
    } catch (error) {
        console.error('Error getting AI response:', error);
        throw error;
    }
}

// Handle sending messages
async function sendMessage(message) {
    if (!message.trim()) return;
    
    // Add user message
    addMessage(message, true);
    userInput.value = '';
    
    // Show typing indicator
    const typingIndicator = showTypingIndicator();
    
    // Get and add AI response
    try {
        const response = await getAIResponse(message);
        typingIndicator.remove();
        addMessage(response);
    } catch (error) {
        typingIndicator.remove();
        // Log the specific error for debugging
        console.error('Chat error:', error);
        
        // Provide more specific error messages based on the error type
        if (error.name === 'NetworkError' || !navigator.onLine) {
            addMessage("I'm having trouble connecting to the network. Please check your internet connection and try again.");
        } else if (error.response?.status === 429) {
            addMessage("I'm receiving too many requests right now. Please wait a moment before trying again.");
        } else {
            addMessage("I apologize, but I'm having trouble processing your message. Could you please try again in a moment?");
        }
    }
}

// Event listeners
sendBtn.addEventListener('click', () => sendMessage(userInput.value));

userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage(userInput.value);
    }
});

// Handle suggestion chips
suggestionChips.forEach(chip => {
    chip.addEventListener('click', () => {
        sendMessage(chip.textContent);
    });
});

// Handle mood tracking
moodButtons.forEach(btn => {
    btn.addEventListener('click', async () => {
        const mood = btn.dataset.mood;
        const value = parseInt(btn.dataset.value);
        
        try {
            await api.recordMood(mood, value, '');
            sendMessage(`I'm feeling ${mood} today`);
        } catch (error) {
            console.error('Error recording mood:', error);
            alert('Error recording mood. Please try again.');
        }
    });
});

// Handle resource buttons
resourceButtons.forEach(btn => {
    btn.addEventListener('click', async () => {
        const resource = btn.textContent.trim();
        let message = "";
        
        switch(resource) {
            case 'Self-Care Tips':
                message = "Could you provide some personalized self-care tips for me?";
                break;
            case 'Breathing Exercises':
                message = "Can you guide me through a breathing exercise?";
                break;
            case 'Mental Health Guide':
                message = "What are some important things I should know about mental health?";
                break;
        }
        
        await sendMessage(message);
    });
});

// Toggle speech function
function toggleSpeech() {
    speechEnabled = !speechEnabled;
    localStorage.setItem('speechEnabled', speechEnabled); // Save preference
    
    if (toggleSpeechBtn) {
        toggleSpeechBtn.classList.toggle('muted');
    }
    
    if (!speechEnabled && window.speechSynthesis) {
        window.speechSynthesis.cancel(); // Stop any ongoing speech
    }
}

// Add click event listener to speech toggle button
if (toggleSpeechBtn) {
    toggleSpeechBtn.addEventListener('click', toggleSpeech);
}

// Function to speak text
function speakText(text) {
    if (!speechEnabled || !window.speechSynthesis) return;
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    window.speechSynthesis.speak(utterance);
}

// Dark mode functionality
const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

// Initialize theme
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        if (savedTheme === 'dark') {
            document.documentElement.classList.add('dark-mode');
        }
    } else if (prefersDarkScheme.matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.documentElement.classList.add('dark-mode');
    }
}

// Toggle dark mode
function toggleDarkMode() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    if (newTheme === 'dark') {
        document.documentElement.classList.add('dark-mode');
    } else {
        document.documentElement.classList.remove('dark-mode');
    }
}

// Event listeners
darkModeToggle.addEventListener('click', toggleDarkMode);
prefersDarkScheme.addEventListener('change', (e) => {
    const newTheme = e.matches ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
});

// Speech Recognition Setup
let recognition = null;
try {
    recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
} catch (e) {
    console.warn('Speech recognition not supported:', e);
    micBtn.style.display = 'none';
}

// Handle speech recognition results
if (recognition) {
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        userInput.value = transcript;
        micBtn.classList.remove('listening');
        sendMessage(transcript);
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        micBtn.classList.remove('listening');
    };

    recognition.onend = () => {
        micBtn.classList.remove('listening');
    };

    // Toggle speech recognition
    micBtn.addEventListener('click', () => {
        if (micBtn.classList.contains('listening')) {
            recognition.stop();
            micBtn.classList.remove('listening');
        } else {
            recognition.start();
            micBtn.classList.add('listening');
            userInput.placeholder = 'Listening...';
        }
    });
}

// Initialize theme on load
initializeTheme();

// Start conversation with error handling
async function startConversation() {
    // Add a delay to allow UI elements to load
    setTimeout(async () => {
        try {
            // Check if the chat is already initialized
            if (conversationStarted) {
                return;
            }
            
            conversationStarted = true;
            const typingIndicator = showTypingIndicator();
            
            try {
                // Try to get an AI greeting - if this fails, we'll show a default greeting
                const response = await getAIResponse("Hello");
                typingIndicator.remove();
                addMessage(response);
            } catch (error) {
                console.error('Error starting conversation:', error);
                typingIndicator.remove();
                
                // Provide a default greeting message if the API fails
                const defaultGreeting = `Hi ${currentUser.firstName}! I'm ${localStorage.getItem('aiName') || 'Friend'}, your AI companion. How are you feeling today?`;
                addMessage(defaultGreeting);
                
                // Add the greeting to conversation history
                conversationHistory.push({
                    role: "model",
                    parts: [{ text: defaultGreeting }]
                });
            }
        } catch (error) {
            console.error('Critical error in conversation initialization:', error);
            // Ensure no typing indicators remain
            const indicators = document.querySelectorAll('.typing-indicator');
            indicators.forEach(indicator => indicator.remove());
            
            // Add a very simple fallback message
            addMessage("Hello! I'm here to chat with you. How are you doing today?");
        }
    }, 1000);
}

// Make sure DOM is fully loaded before initializing chat
document.addEventListener('DOMContentLoaded', () => {
    // Initialize only if we're on the chat page
    if (chatBox) {
        startConversation();
    }
});
