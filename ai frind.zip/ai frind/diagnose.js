/**
 * AI Friend Project Diagnostic Tool
 * 
 * This script helps diagnose common issues with the AI Friend project
 * and provides suggestions for fixing them.
 */

const { spawn, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');
const net = require('net');

console.log('🔍 AI Friend Project Diagnostic Tool 🔍\n');
console.log('Running diagnostics to identify connection issues...\n');

// Check if port is in use
function checkPortInUse(port) {
    return new Promise((resolve) => {
        const server = net.createServer();
        
        server.once('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                resolve(true); // Port is in use
            } else {
                resolve(false);
            }
        });
        
        server.once('listening', () => {
            server.close();
            resolve(false); // Port is available
        });
        
        server.listen(port);
    });
}

// Check file existence
function checkFileExists(filePath) {
    try {
        return fs.existsSync(filePath);
    } catch (error) {
        return false;
    }
}

// Run diagnostics
async function runDiagnostics() {
    console.log('1. Checking for critical files...');
    
    // Check for critical files
    const criticalFiles = [
        'index.html',
        'chat.html',
        'login.html',
        'server/server.js',
        'js/api.js',
        'config.js',
        'gemini-integration.js',
        'package.json'
    ];
    
    let missingFiles = [];
    for (const file of criticalFiles) {
        if (!checkFileExists(file)) {
            missingFiles.push(file);
        }
    }
    
    if (missingFiles.length > 0) {
        console.log('⚠️ Missing critical files:');
        missingFiles.forEach(file => console.log(`   - ${file}`));
    } else {
        console.log('✅ All critical files present');
    }
    
    // Check port availability
    console.log('\n2. Checking port availability...');
    
    const backendPortInUse = await checkPortInUse(5000);
    const frontendPortInUse = await checkPortInUse(8080);
    
    if (backendPortInUse) {
        console.log('⚠️ Port 5000 (backend) is already in use by another application');
    } else {
        console.log('✅ Port 5000 (backend) is available');
    }
    
    if (frontendPortInUse) {
        console.log('⚠️ Port 8080 (frontend) is already in use by another application');
    } else {
        console.log('✅ Port 8080 (frontend) is available');
    }
    
    // Check network connectivity
    console.log('\n3. Testing network connectivity...');
    
    try {
        // Try to make a simple HTTP request to a reliable server
        const request = http.get('http://www.google.com', (res) => {
            if (res.statusCode === 200 || res.statusCode === 301 || res.statusCode === 302) {
                console.log('✅ Internet connection is working');
            } else {
                console.log('⚠️ Internet connection might have issues (HTTP status: ' + res.statusCode + ')');
            }
            
            // Continue with more diagnostics
            checkEnvironment();
        });
        
        request.on('error', (err) => {
            console.log('⚠️ Internet connection error:', err.message);
            // Continue with more diagnostics
            checkEnvironment();
        });
        
        request.end();
    } catch (error) {
        console.log('⚠️ Internet connection test failed:', error.message);
        // Continue with more diagnostics
        checkEnvironment();
    }
}

// Check environment
function checkEnvironment() {
    console.log('\n4. Checking environment configuration...');
    
    // Check for Node.js version
    exec('node --version', (error, stdout, stderr) => {
        if (error) {
            console.log('⚠️ Failed to get Node.js version:', error.message);
        } else {
            const version = stdout.trim();
            console.log(`✅ Node.js version: ${version}`);
            
            // Check if Node.js version is compatible
            const versionNumber = version.replace('v', '').split('.').map(Number);
            if (versionNumber[0] < 14) {
                console.log('⚠️ Node.js version should be 14.0.0 or higher for optimal compatibility');
            }
        }
        
        // Check NPM
        exec('npm --version', (error, stdout, stderr) => {
            if (error) {
                console.log('⚠️ Failed to get npm version:', error.message);
            } else {
                console.log(`✅ npm version: ${stdout.trim()}`);
            }
            
            // Print diagnostic summary
            printDiagnosticSummary();
        });
    });
}

// Print diagnostic summary and suggestions
function printDiagnosticSummary() {
    console.log('\n📋 DIAGNOSTIC SUMMARY & RECOMMENDATIONS:\n');
    
    console.log('If you\'re seeing "This site can\'t be reached" or "Connection refused" errors:');
    console.log('1. Try these alternative ways to start the application:');
    console.log('   - Run: npm run local-frontend');
    console.log('   - Run: npm run simple-server');
    console.log('   - Run: npm run open-direct (opens the HTML file directly, limited functionality)');
    
    console.log('\n2. If ports are already in use:');
    console.log('   - Close any other applications using ports 5000 or 8080');
    console.log('   - Modify the PORT environment variable in .env file');
    console.log('   - Use a different port: npx http-server . -p 9000 --cors');
    
    console.log('\n3. If network issues persist:');
    console.log('   - Check your firewall settings');
    console.log('   - Try running with Administrator/sudo privileges');
    console.log('   - Check if your antivirus is blocking the connections');
    
    console.log('\n4. For specific browser issues:');
    console.log('   - Try a different browser (Chrome, Firefox, Edge)');
    console.log('   - Clear browser cache and cookies');
    console.log('   - Disable browser extensions that might be interfering');
    
    console.log('\nWould you like to try a different approach now? (Run one of the commands above)');
}

// Start the diagnostics
runDiagnostics(); 