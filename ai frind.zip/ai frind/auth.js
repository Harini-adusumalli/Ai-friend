// Client-side storage for demo purposes
const users = JSON.parse(localStorage.getItem('users')) || [];

// Determine the base URL for API calls
function getBaseUrl() {
    // Use the same host if not localhost
    if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
        return `${window.location.protocol}//${window.location.hostname}`;
    }
    return 'http://localhost:5000';
}

// Client-side authentication
async function signup(userData) {
    try {
        const baseUrl = getBaseUrl();
        console.log('Attempting signup to:', `${baseUrl}/api/users/register`);
        
        try {
            const response = await fetch(`${baseUrl}/api/users/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            const data = await response.json();
            console.log('Signup response status:', response.status);
            console.log('Signup response data:', data);
            
            if (!response.ok) {
                throw new Error(data.message || 'Registration failed');
            }

            // Store token and user data
            localStorage.setItem('token', data.token);
            localStorage.setItem('currentUser', JSON.stringify(data.user));

            return data;
        } catch (fetchError) {
            console.error('Server connection error:', fetchError);
            
            // If server is unavailable, fall back to client-side demo mode
            if (fetchError.name === 'TypeError' && fetchError.message.includes('Failed to fetch')) {
                console.warn('Server unavailable, using client-side fallback for demo purposes');
                
                // Check if email already exists
                if (users.some(user => user.email === userData.email)) {
                    throw new Error('Email already in use');
                }
                
                // Generate a demo user with ID
                const newUser = {
                    id: Date.now().toString(),
                    ...userData,
                    password: '[PROTECTED]' // Don't store actual password
                };
                
                // Store in local array
                users.push(newUser);
                localStorage.setItem('users', JSON.stringify(users));
                
                // Create a fake token
                const token = `demo_token_${Math.random().toString(36).substring(2)}`;
                localStorage.setItem('token', token);
                localStorage.setItem('currentUser', JSON.stringify(newUser));
                
                return {
                    token,
                    user: newUser,
                    message: 'Account created successfully (Demo Mode)'
                };
            }
            
            throw fetchError;
        }
    } catch (error) {
        console.error('Signup error details:', error);
        throw error;
    }
}

async function login(credentials) {
    try {
        const baseUrl = getBaseUrl();
        console.log('Attempting login to:', `${baseUrl}/api/users/login`);
        console.log('With credentials:', { email: credentials.email, passwordLength: credentials.password?.length });
        
        try {
            const response = await fetch(`${baseUrl}/api/users/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(credentials)
            });

            console.log('Login response status:', response.status);
            const data = await response.json();
            console.log('Login response data:', data);
            
            if (!response.ok) {
                if (data.clearToken) {
                    // Clear invalid tokens
                    localStorage.removeItem('token');
                    localStorage.removeItem('currentUser');
                }
                throw new Error(data.message || 'Login failed');
            }

            // Store new token and user data
            localStorage.setItem('token', data.token);
            localStorage.setItem('currentUser', JSON.stringify(data.user));

            return data;
        } catch (fetchError) {
            console.error('Server connection error:', fetchError);
            
            // If server is unavailable, fall back to client-side demo mode
            if (fetchError.name === 'TypeError' && fetchError.message.includes('Failed to fetch')) {
                console.warn('Server unavailable, using client-side fallback for demo purposes');
                
                // Find user in local storage
                const user = users.find(user => user.email === credentials.email);
                
                if (!user) {
                    throw new Error('Invalid email or password');
                }
                
                // In a real app we would verify the password, but since passwords
                // are not stored client-side, we'll just proceed for the demo
                
                // Create a fake token
                const token = `demo_token_${Math.random().toString(36).substring(2)}`;
                localStorage.setItem('token', token);
                localStorage.setItem('currentUser', JSON.stringify(user));
                
                return {
                    token,
                    user,
                    message: 'Login successful (Demo Mode)'
                };
            }
            
            throw fetchError;
        }
    } catch (error) {
        console.error('Login error details:', error);
        throw error;
    }
}

// Signup functionality
const signupForm = document.getElementById('signupForm');
if (signupForm) {
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Get form elements
        const firstNameInput = document.getElementById('firstName');
        const lastNameInput = document.getElementById('lastName');
        const ageInput = document.getElementById('age');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const errorDisplay = document.getElementById('signupError');
        
        // Reset error display
        if (errorDisplay) {
            errorDisplay.style.display = 'none';
            errorDisplay.textContent = '';
        }
        
        // Client-side validation
        if (passwordInput.value.length < 6) {
            if (errorDisplay) {
                errorDisplay.textContent = 'Password must be at least 6 characters long';
                errorDisplay.style.display = 'block';
            } else {
                alert('Password must be at least 6 characters long');
            }
            return;
        }
        
        if (parseInt(ageInput.value) < 13) {
            if (errorDisplay) {
                errorDisplay.textContent = 'You must be at least 13 years old to register';
                errorDisplay.style.display = 'block';
            } else {
                alert('You must be at least 13 years old to register');
            }
            return;
        }
        
        const userData = {
            firstName: firstNameInput.value,
            lastName: lastNameInput.value,
            age: ageInput.value,
            email: emailInput.value,
            password: passwordInput.value
        };

        try {
            // Show loading state
            const submitButton = signupForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.textContent = 'Creating Account...';
            
            await signup(userData);
            window.location.href = 'chat.html';
        } catch (error) {
            // Display error message in the error container if it exists
            if (errorDisplay) {
                errorDisplay.textContent = error.message || 'Registration failed. Please try again.';
                errorDisplay.style.display = 'block';
            } else {
                alert(error.message || 'Registration failed. Please try again.');
            }
            
            // Re-enable the submit button
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
            }
        }
    });
}

// Login functionality
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Get form elements
        const emailInput = document.getElementById('loginEmail');
        const passwordInput = document.getElementById('loginPassword');
        const errorDisplay = document.getElementById('loginError') || 
            document.createElement('div');
        
        // Clear previous errors
        errorDisplay.textContent = '';
        errorDisplay.id = 'loginError';
        errorDisplay.style.color = 'red';
        errorDisplay.style.marginBottom = '1rem';
        
        if (!loginForm.contains(errorDisplay)) {
            loginForm.insertBefore(errorDisplay, loginForm.firstChild);
        }

        try {
            const credentials = {
                email: emailInput.value.trim(),
                password: passwordInput.value
            };

            // Validate input
            if (!credentials.email || !credentials.password) {
                errorDisplay.textContent = 'Email and password are required';
                return;
            }

            await login(credentials);
            window.location.href = 'chat.html';
        } catch (error) {
            errorDisplay.textContent = error.message || 'Login failed. Please try again.';
            passwordInput.value = ''; // Clear password field on error
        }
    });
}

// Check authentication status
function checkAuth() {
    const token = localStorage.getItem('token');
    const currentUser = localStorage.getItem('currentUser');
    
    // Determine if we're on an authentication page
    const currentPath = window.location.pathname;
    const isAuthPage = currentPath.endsWith('login.html') || 
                       currentPath.endsWith('signup.html') || 
                       currentPath === '/' || 
                       currentPath.endsWith('index.html');

    // Clear invalid data
    if (token && !currentUser) {
        localStorage.removeItem('token');
    }
    
    if (!token && currentUser) {
        localStorage.removeItem('currentUser');
    }

    // Handle redirection based on auth status and current page
    if (!token && !isAuthPage) {
        // If token is missing and we're not on an auth page, redirect to login
        console.log('Not authenticated, redirecting to login page');
        
        // Use timeout to avoid immediate redirect that might interrupt other scripts
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 100);
    } else if (token && isAuthPage && currentUser) {
        // If we have valid auth data but we're on an auth page, redirect to chat
        // Only redirect if we actually have user data
        console.log('Already authenticated, redirecting to app');
        
        // Use timeout to avoid immediate redirect that might interrupt other scripts
        setTimeout(() => {
            window.location.href = 'chat.html';
        }, 100);
    }

    // Update user name in UI if available
    const userNameElement = document.getElementById('userName');
    if (userNameElement && currentUser) {
        try {
            const user = JSON.parse(currentUser);
            if (user && user.firstName) {
                userNameElement.textContent = user.firstName || 'User';
            }
        } catch (error) {
            console.error('Error parsing user data:', error);
        }
    }
}

// Logout functionality
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        localStorage.clear(); // Clear all storage
        window.location.href = 'login.html';
    });
}

// Run authentication check
checkAuth();
