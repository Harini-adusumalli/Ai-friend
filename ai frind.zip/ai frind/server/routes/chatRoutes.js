const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Chat = require('../models/Chat');
const geminiService = require('../services/GeminiService');

// Get chat history
router.get('/history', auth, async (req, res) => {
    try {
        const messages = await Chat.find({ user: req.user.userId })
            .sort({ createdAt: 1 })
            .select('role content createdAt');
        res.json(messages);
    } catch (error) {
        console.error('Error fetching chat history:', error);
        res.status(500).json({ message: 'Error fetching chat history' });
    }
});

// Send message
router.post('/message', auth, async (req, res) => {
    try {
        const { content } = req.body;
        
        if (!content) {
            return res.status(400).json({ 
                message: 'Message content is required' 
            });
        }

        // Save user message
        const userMessage = new Chat({
            user: req.user.userId,
            role: 'user',
            content
        });
        await userMessage.save();

        try {
            // Set a timeout for the AI response
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('AI response timeout')), 20000);
            });

            // Get AI response with timeout
            const responseText = await Promise.race([
                geminiService.generateChatResponse(content),
                timeoutPromise
            ]);

            // Save AI response
            const assistantMessage = new Chat({
                user: req.user.userId,
                role: 'assistant',
                content: responseText
            });
            await assistantMessage.save();

            res.json({ response: responseText });
        } catch (aiError) {
            console.error('AI service error:', aiError);
            
            // Still save a generic response in the database
            const fallbackMessage = "I apologize, but I'm having trouble processing your request right now. Please try again later.";
            const assistantMessage = new Chat({
                user: req.user.userId,
                role: 'assistant',
                content: fallbackMessage
            });
            await assistantMessage.save();
            
            // Return appropriate error based on the type
            if (aiError.message === 'AI response timeout') {
                return res.status(504).json({ 
                    message: 'The AI service is taking too long to respond. Please try again later.'
                });
            } else if (aiError.message.includes('404')) {
                return res.status(503).json({ 
                    message: 'The AI service is currently unavailable. Please try again later.'
                });
            } else {
                return res.status(500).json({ 
                    message: 'Sorry, I\'m having trouble responding right now. Please try again later.' 
                });
            }
        }
    } catch (error) {
        console.error('Chat error:', error);
        res.status(500).json({ 
            message: 'Sorry, I\'m having trouble responding right now. Please try again later.' 
        });
    }
});

module.exports = router; 