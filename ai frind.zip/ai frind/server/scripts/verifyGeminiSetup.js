const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

async function verifyGeminiSetup() {
    try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

        const prompt = "Hello! Please respond with 'API Connection Successful' if you receive this message.";
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        console.log('Gemini API Test Result:', text);
        return true;
    } catch (error) {
        console.error('Gemini API Setup Error:', error);
        return false;
    }
}

module.exports = verifyGeminiSetup;