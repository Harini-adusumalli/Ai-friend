const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');

dotenv.config();

async function createTestUser() {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        // Delete existing test user
        await User.deleteOne({ email: 'test@example.com' });
        console.log('Cleaned up existing test user');

        // Create new test user
        const testUser = new User({
            firstName: 'Test',
            lastName: 'User',
            email: 'test@example.com',
            password: 'password123', // Will be hashed by the pre-save middleware
            age: 25,
            aiName: 'Friend'
        });

        // Save the user
        const savedUser = await testUser.save();
        console.log('Test user created successfully:', {
            id: savedUser._id,
            email: savedUser.email,
            firstName: savedUser.firstName,
            lastName: savedUser.lastName
        });

        // Verify the user exists and can be found
        const verifyUser = await User.findOne({ email: 'test@example.com' });
        if (verifyUser) {
            console.log('Verified user exists in database');
        } else {
            console.log('WARNING: User was not found after creation!');
        }

        await mongoose.connection.close();
        console.log('Database connection closed');
    } catch (error) {
        console.error('Error creating test user:', error);
        await mongoose.connection.close();
        process.exit(1);
    }
}

createTestUser(); 