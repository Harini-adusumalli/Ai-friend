const dotenv = require('dotenv');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

// Load environment variables from root .env
dotenv.config({ path: path.join(__dirname, '../../.env') });

async function resetAndTest() {
    console.log('\nResetting and Testing System');
    console.log('==========================\n');

    // 1. Test JWT
    console.log('1. Testing JWT Configuration:');
    console.log('---------------------------');
    try {
        const testPayload = { userId: 'test', email: 'test@example.com' };
        const token = jwt.sign(testPayload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log('✅ JWT signing and verification successful');
    } catch (error) {
        console.error('❌ JWT test failed:', error.message);
        return false;
    }

    // 2. Test Gemini API
    console.log('\n2. Testing Gemini API Connection:');
    console.log('-------------------------------');
    try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
        
        console.log('Sending test request...');
        const result = await model.generateContent('Say "Hello, testing connection!"');
        const response = await result.response;
        console.log('✅ Gemini API response:', response.text());
    } catch (error) {
        console.error('❌ Gemini API test failed!');
        if (error.message.includes('API_KEY_INVALID')) {
            console.log('\nPlease get a new API key from:');
            console.log('https://makersuite.google.com/app/apikey');
        }
        console.error('Error:', error.message);
        return false;
    }

    // 3. Test MongoDB Connection
    console.log('\n3. Testing MongoDB Connection:');
    console.log('----------------------------');
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('✅ MongoDB connection successful');
        await mongoose.connection.close();
    } catch (error) {
        console.error('❌ MongoDB connection failed:', error.message);
        return false;
    }

    console.log('\n✅ All tests passed successfully!');
    return true;
}

// Run the tests
resetAndTest()
    .then(success => {
        if (!success) {
            console.log('\n❌ Some tests failed. Please fix the issues above.');
            process.exit(1);
        }
        process.exit(0);
    })
    .catch(error => {
        console.error('\n❌ Tests failed with error:', error);
        process.exit(1);
    }); 