const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '../../.env') });

async function verifyJWTSetup() {
    console.log('\nVerifying JWT Setup');
    console.log('==================\n');

    // Check JWT secret
    if (!process.env.JWT_SECRET) {
        console.error('❌ JWT_SECRET is not set in .env file');
        return false;
    }

    try {
        // Create a test token
        const testPayload = { userId: 'test' };
        console.log('Creating test token...');
        const token = jwt.sign(testPayload, process.env.JWT_SECRET);

        // Verify the token
        console.log('Verifying test token...');
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        console.log('✅ JWT signing and verification successful');
        console.log('Test payload:', decoded);
        return true;
    } catch (error) {
        console.error('❌ JWT test failed:', error.message);
        return false;
    }
}

// Run verification
verifyJWTSetup().then(success => {
    if (!success) {
        console.log('\n❌ JWT setup verification failed');
        process.exit(1);
    }
    console.log('\n✅ JWT setup verification completed successfully');
    process.exit(0);
}); 