const dotenv = require('dotenv');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const jwt = require('jsonwebtoken');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '../../.env') });

async function verifySetup() {
    console.log('\nVerifying System Setup');
    console.log('=====================\n');

    // 1. Check Environment Variables
    console.log('1. Checking Environment Variables:');
    const requiredVars = ['JWT_SECRET', 'GEMINI_API_KEY', 'MONGODB_URI'];
    requiredVars.forEach(varName => {
        if (!process.env[varName]) {
            console.error(`❌ ${varName} is not set`);
        } else {
            console.log(`✅ ${varName} is set`);
        }
    });

    // 2. Test JWT
    console.log('\n2. Testing JWT:');
    try {
        const testPayload = { userId: 'test' };
        const token = jwt.sign(testPayload, process.env.JWT_SECRET);
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log('✅ JWT working correctly');
    } catch (error) {
        console.error('❌ JWT test failed:', error.message);
    }

    // 3. Test Gemini API
    console.log('\n3. Testing Gemini API:');
    try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
        const result = await model.generateContent('Test connection');
        console.log('✅ Gemini API working correctly');
    } catch (error) {
        console.error('❌ Gemini API test failed:', error.message);
        if (error.message.includes('API_KEY_INVALID')) {
            console.log('\nPlease get a new API key from:');
            console.log('https://makersuite.google.com/app/apikey');
        }
    }
}

// Run verification
verifySetup().catch(console.error); 