const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');

dotenv.config();

async function checkDatabase() {
    try {
        console.log('Connecting to MongoDB Atlas...');
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Successfully connected to MongoDB Atlas!');

        // Check for users collection
        const collections = await mongoose.connection.db.listCollections().toArray();
        console.log('\nCollections:', collections.map(c => c.name));

        // Count users
        const userCount = await User.countDocuments();
        console.log('\nTotal users:', userCount);

        // List all users
        const users = await User.find({});
        console.log('\nUsers:', users.map(user => ({
            id: user._id,
            email: user.email,
            firstName: user.firstName
        })));

        await mongoose.connection.close();
        console.log('\nDatabase connection closed');
    } catch (error) {
        console.error('Database connection error:', error);
        if (error.name === 'MongoNetworkError') {
            console.log('\nTip: Make sure your IP address is whitelisted in MongoDB Atlas');
        }
        await mongoose.connection.close();
    }
}

checkDatabase(); 