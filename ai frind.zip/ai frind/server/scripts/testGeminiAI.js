const geminiService = require('../services/GeminiService');

async function testGeminiService() {
    try {
        console.log('Testing Gemini AI Service...');
        
        // Test journal analysis
        console.log('\nTesting journal analysis...');
        const journalResponse = await geminiService.analyzeJournalEntry('Today was a good day. I felt productive and happy.');
        console.log('Journal analysis response:', journalResponse);

        // Test mood analysis
        console.log('\nTesting mood analysis...');
        const moodResponse = await geminiService.analyzeMood('happy', 'Completed all my tasks today');
        console.log('Mood analysis response:', moodResponse);

        console.log('\nAll tests completed successfully!');
    } catch (error) {
        console.error('Test failed:', error);
    }
}

testGeminiService(); 