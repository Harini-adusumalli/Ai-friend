require('dotenv').config();
const config = require('../../config');

function validateEnvironment() {
    console.log('Validating environment configuration...');

    // Check required variables
    const requiredVars = [
        'MONGODB_URI',
        'JWT_SECRET',
        'GEMINI_API_KEY'
    ];

    const missingVars = requiredVars.filter(varName => !process.env[varName]);
    if (missingVars.length > 0) {
        console.error('❌ Missing required environment variables:');
        missingVars.forEach(varName => console.error(`   - ${varName}`));
        process.exit(1);
    }

    // Validate MongoDB URI format
    if (!process.env.MONGODB_URI.startsWith('mongodb+srv://')) {
        console.error('❌ Invalid MongoDB URI format');
        process.exit(1);
    }

    // Validate JWT secret length
    if (process.env.JWT_SECRET.length < 32) {
        console.error('❌ JWT_SECRET must be at least 32 characters long');
        process.exit(1);
    }

    // Validate Gemini API key format
    if (!process.env.GEMINI_API_KEY.startsWith('AIza')) {
        console.error('❌ Invalid Gemini API key format');
        process.exit(1);
    }

    console.log('✅ Environment configuration is valid');
}

validateEnvironment(); 