const mongoose = require('mongoose');

const journalSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    content: {
        type: String,
        required: true
    },
    aiAnalysis: String,
    mood: {
        type: String,
        enum: ['great', 'good', 'okay', 'bad', 'awful']
    },
    tasks: [{
        text: String,
        completed: {
            type: Boolean,
            default: false
        },
        isAISuggestion: {
            type: Boolean,
            default: false
        }
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Journal', journalSchema); 