const { GoogleGenerativeAI } = require('@google/generative-ai');
const config = require('../../config');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables from the root .env file
dotenv.config({ path: path.join(__dirname, '../../.env') });

class GeminiService {
    constructor() {
        if (!config.gemini.apiKey) {
            throw new Error('GEMINI_API_KEY is not configured');
        }
        this.genAI = new GoogleGenerativeAI(config.gemini.apiKey);
        this.model = this.genAI.getGenerativeModel({ model: "gemini-pro" });
    }

    isValidApiKeyFormat(key) {
        // Check if key matches Google API key format
        return /^AIza[A-Za-z0-9_-]{35}$/.test(key);
    }

    async testConnection() {
        try {
            console.log('Testing Gemini AI connection...');
            const prompt = 'Respond with "Connection successful" if you can read this.';
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();
            
            if (text.includes('Connection successful')) {
                console.log('✅ Connection test passed');
                return true;
            } else {
                console.log('❌ Unexpected response:', text);
                return false;
            }
        } catch (error) {
            console.error('Connection test failed:', error);
            if (error.message.includes('API_KEY_INVALID')) {
                console.log('\nPlease follow these steps to fix the API key:');
                console.log('1. Go to https://makersuite.google.com/app/apikey');
                console.log('2. Enable the Gemini API if not already enabled');
                console.log('3. Create a new API key');
                console.log('4. Update your .env file with the new key');
            }
            throw error;
        }
    }

    async generateChatResponse(message) {
        if (!message) {
            throw new Error('Message is required');
        }

        try {
            const result = await this.model.generateContent({
                contents: [{ role: 'user', parts: [{ text: message }] }],
                generationConfig: {
                    temperature: 0.7,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 1024,
                }
            });

            const response = await result.response;
            return response.text();
        } catch (error) {
            console.error('Chat response error:', error);
            throw new Error('Failed to generate chat response');
        }
    }

    async generateResponse(prompt) {
        try {
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            return response.text();
        } catch (error) {
            console.error('Gemini API Error:', error);
            throw new Error('Failed to generate response from Gemini AI');
        }
    }

    async analyzeJournalEntry(content) {
        try {
            console.log('Analyzing journal entry...');
            
            const prompt = `
                As an empathetic AI assistant, analyze this journal entry and provide supportive insights.
                Focus on identifying emotions, patterns, and offering gentle encouragement.
                Keep the response concise and supportive.
                
                Journal entry: "${content}"
            `;

            return await this.generateResponse(prompt);
        } catch (error) {
            console.error('Journal analysis error:', error);
            return 'AI insights temporarily unavailable. Please try again later.';
        }
    }

    async analyzeMood(mood, notes = '') {
        try {
            const prompt = `
                As an AI wellness companion, analyze this mood data and provide:
                1. A brief empathetic response
                2. 2-3 personalized activity suggestions
                3. A relevant wellness tip
                
                User's mood: ${mood}
                ${notes ? `Additional context: ${notes}` : ''}
                
                Keep the total response under 150 words and format with clear sections.
            `;

            return await this.generateResponse(prompt);
        } catch (error) {
            console.error('Mood analysis error:', error);
            return 'Mood analysis temporarily unavailable. Please try again later.';
        }
    }

    async getMeditationGuide(duration, type) {
        try {
            const prompt = `
                Create a gentle meditation script for:
                Duration: ${duration} minutes
                Type: ${type}
                Keep it calming and supportive.
            `;

            return await this.generateResponse(prompt);
        } catch (error) {
            console.error('Meditation guide error:', error);
            return 'Meditation guide temporarily unavailable. Please try again later.';
        }
    }
}

module.exports = new GeminiService(); 