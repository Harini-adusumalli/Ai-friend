import { api } from './api.js';

class GeminiAI {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.fallbackMode = false;
        this.modelName = "gemini-1.5-pro"; // Store model name as a property
        
        // Validate API key format and immediately set fallback mode if invalid
        if (!apiKey || !this.isValidApiKeyFormat(apiKey)) {
            console.warn('Invalid or missing Gemini API key format, operating in fallback mode');
            this.fallbackMode = true;
        }
        
        // Log initialization state
        console.log(`Gemini AI initialized with model: ${this.modelName}. Fallback mode: ${this.fallbackMode}`);
    }
    
    // Utility method to check if API key format is valid
    isValidApiKeyFormat(key) {
        return typeof key === 'string' && /^AIza[A-Za-z0-9_-]{35}$/.test(key);
    }

    async generateResponse(prompt) {
        // Use fallback immediately if in fallback mode
        if (this.fallbackMode) {
            console.log('Using fallback response for prompt:', prompt.substring(0, 50) + '...');
            return this.generateFallbackResponse(prompt);
        }
        
        try {
            // Using the model name from the class property
            console.log(`Calling Gemini API with model: ${this.modelName}`);
            
            const response = await fetch(`https://generativelanguage.googleapis.com/v1/models/${this.modelName}:generateContent?key=${this.apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: prompt
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 1024,
                    }
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error('Gemini API error response:', errorData);
                
                // Switch to fallback mode if we get an error
                this.fallbackMode = true;
                console.warn('Switching to fallback mode due to API error');
                
                // Better error detection for 404 errors (model not found)
                if (errorData.error && errorData.error.code === 404) {
                    if (errorData.error.message && (
                        errorData.error.message.includes('models/gemini-pro is not found') || 
                        errorData.error.message.includes(`models/${this.modelName} is not found`))) {
                        console.error(`Error: The model "${this.modelName}" is not available. Using fallback mode.`);
                    } else {
                        console.error('Error: Model not found. Check available models in the Gemini API.');
                    }
                    return this.generateFallbackResponse(prompt);
                }
                
                return this.generateFallbackResponse(prompt);
            }

            const data = await response.json();
            
            // Check if response format is valid
            if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts) {
                console.error('Invalid response format from Gemini API:', data);
                this.fallbackMode = true;
                return this.generateFallbackResponse(prompt);
            }
            
            return data.candidates[0].content.parts[0].text;
        } catch (error) {
            console.error('Error calling Gemini API:', error);
            
            // Switch to fallback mode on any error
            this.fallbackMode = true;
            return this.generateFallbackResponse(prompt);
        }
    }

    generateFallbackResponse(prompt) {
        console.log('Using fallback response generator for prompt:', prompt);
        
        if (prompt.includes('analyze this journal entry')) {
            return `🌟 Thank you for sharing your thoughts! It seems like you're processing quite a bit.

📝 Here are some suggestions that might help:
- 🧘 Take 10 minutes for mindful breathing
- 📋 Break down any overwhelming tasks into smaller steps
- 🌳 Consider a short walk outside to clear your mind
- 🛌 Ensure you're getting enough rest

✨ Remember that you're doing great, and each journal entry is a step toward self-awareness and growth!`;
        }
        
        if (prompt.includes('Extract the tasks')) {
            return `🧘 Take 10 minutes for mindful breathing
📋 Break down any overwhelming tasks into smaller steps
🌳 Consider a short walk outside to clear your mind
🛌 Ensure you're getting enough rest`;
        }

        if (prompt.includes('self-care recommendations')) {
            return `🫂 Emotional Wellness
- Practice 5 minutes of mindfulness meditation daily
- Write down three things you're grateful for each evening
- Set healthy boundaries with work and social media

💪 Physical Wellness
- Take a 15-minute walk outside each day
- Stay hydrated by drinking water throughout the day
- Stretch for 5 minutes every few hours if sitting for long periods

🧠 Mental Wellness
- Schedule short breaks during work to prevent burnout
- Try the Pomodoro technique (25 min work, 5 min break)
- Keep a small notebook for ideas and thoughts to reduce mental clutter

👥 Social Wellness
- Reach out to one friend or family member you haven't spoken to lately
- Join a community group related to your interests
- Schedule quality time with loved ones without digital distractions`;
        }
        
        if (prompt.includes('self-care challenge')) {
            return `✨ Mindful Reset Challenge

Today is perfect for a gentle reset to help you feel more centered and calm.

1. 🌅 Morning Moment (5 minutes)
   Set a positive intention for the day while taking 10 deep breaths

2. 🧘 Midday Pause (10 minutes)
   Find a quiet spot to sit and focus just on your breathing, letting thoughts pass by

3. 🍵 Afternoon Ritual (5 minutes)
   Make a soothing tea or water with lemon, drinking it slowly without distractions

4. 🌙 Evening Reflection (5 minutes)
   Write down 3 positive moments from today, no matter how small

Remember that small, consistent acts of self-care create powerful positive change over time!`;
        }
        
        if (prompt.includes('suggest 3 personalized tasks')) {
            return `✨ Task: Take 15 minutes to write down your thoughts and feelings
💭 Why: Expressing yourself through writing can help clarify your emotions and reduce stress

✨ Task: Go for a 20-minute walk outdoors
💭 Why: Physical movement and fresh air can improve your mood and give you new perspective

✨ Task: Reach out to a friend or family member you trust
💭 Why: Social connection is important for emotional wellbeing and can provide needed support`;
        }
        
        // For analyze mood and suggest
        if (prompt.includes('analyze this mood data') || prompt.includes('AI wellness companion')) {
            return `I see you're feeling this way today. That's completely valid.

Here are some activities that might help:
- 🧘‍♂️ Try a 5-minute mindfulness exercise to center yourself
- 🚶‍♀️ Take a short walk outside to change your environment
- 🎵 Listen to music that matches how you want to feel

Wellness tip: Remember that all emotions are temporary and serve a purpose. Acknowledging them without judgment is the first step toward emotional balance.`;
        }
        
        return "I'm sorry, I'm currently operating with limited capabilities. Your request has been recorded, and we're working to restore full functionality soon. In the meantime, please try again later or use a simpler request format.";
    }

    async analyzeMoodAndSuggest(mood, notes = '') {
        const prompt = `As a friendly AI companion, analyze this mood data and provide a cheerful response with emojis:
        1. A warm, empathetic response with relevant emojis
        2. 2-3 fun activity suggestions, each with a matching emoji
        3. An uplifting wellness tip with emojis
        
        User's mood: ${mood}
        ${notes ? `Additional context: ${notes}` : ''}
        
        Keep the response friendly and upbeat, using emojis to add personality! Format with clear sections.`;

        return await this.generateResponse(prompt);
    }

    async analyzeJournalAndSuggestTasks(journalText) {
        const prompt = `As a supportive AI friend, analyze this journal entry and provide a fun, emoji-rich response:
        1. 🌟 A warm, understanding response to their entry (use relevant mood emojis)
        2. 📝 3-5 actionable tasks/goals based on their entry (add a fitting emoji for each task)
        3. ✨ An encouraging message with motivational emojis
        
        Journal Entry: ${journalText}
        
        Make the response friendly and engaging, using emojis to bring the suggestions to life! Keep it structured and supportive.`;

        return await this.generateResponse(prompt);
    }

    async extractTasksFromAnalysis(analysis) {
        const prompt = `Extract the tasks from this AI analysis and add fun, relevant emojis:

        Analysis: ${analysis}

        Return each task with a matching emoji at the start of the line. Make sure each task is practical and actionable.`;

        const response = await this.generateResponse(prompt);
        return response.split('\n').filter(task => task.trim());
    }

    async analyzeSelfCareNeeds(journalEntries) {
        const prompt = `Based on these journal entries, provide personalized self-care recommendations in four categories. Format your response exactly as shown, using these exact emojis and headers:

        🫂 Emotional Wellness
        [3 specific recommendations for emotional well-being]

        💪 Physical Wellness
        [3 specific recommendations for physical health]

        🧠 Mental Wellness
        [3 specific recommendations for mental clarity]

        👥 Social Wellness
        [3 specific recommendations for social connections]

        Journal Entries: ${journalEntries}

        Make each recommendation specific, actionable, and directly related to the journal content. Use positive, encouraging language.`;

        try {
            const response = await this.generateResponse(prompt);
            return response;
        } catch (error) {
            console.error('Error generating self-care recommendations:', error);
            return this.generateFallbackResponse(prompt);
        }
    }

    async generateDailyChallenge(recentMoods, completedChallenges) {
        const prompt = `Create a step-by-step self-care challenge for today, considering:
        Recent moods: ${recentMoods}
        Previously completed challenges: ${completedChallenges}

        Format the challenge as:
        1. Title with emoji
        2. Brief encouraging intro
        3. 3-4 clear, numbered steps
        4. Each step should:
           - Start with an emoji
           - Be specific and actionable
           - Take 5-15 minutes
           - Build upon previous steps
        5. End with a motivational note

        Make it:
        - Completable in one day
        - Different from previous challenges
        - Relevant to their emotional state
        - Easy to follow
        `;

        return await this.generateResponse(prompt);
    }

    async suggestTasks(journalContent = '', mood = '') {
        const prompt = `As an AI assistant, suggest 3 personalized tasks based on this journal entry and mood:

        Journal content: ${journalContent}
        Current mood: ${mood}

        Please provide:
        1. Three specific, actionable tasks that would be helpful for the user
        2. Each task should be realistic and completable today
        3. Include a brief explanation of why each task would be beneficial
        4. Use emojis to make the suggestions friendly and engaging

        Format each task like this:
        ✨ Task: [task description]
        💭 Why: [brief explanation]

        Keep the tone supportive and encouraging!`;

        try {
            const response = await this.generateResponse(prompt);
            return response;
        } catch (error) {
            console.error('Error generating task suggestions:', error);
            return this.generateFallbackResponse(prompt);
        }
    }
}

export default GeminiAI;

// Move MoodTracker to its own file 