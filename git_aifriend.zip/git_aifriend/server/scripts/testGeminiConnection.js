const dotenv = require('dotenv');
const { GoogleGenerativeAI } = require('@google/generative-ai');

dotenv.config();

async function testGeminiConnection() {
    try {
        console.log('\nTesting Gemini AI Connection');
        console.log('---------------------------');
        console.log('API Key:', process.env.GEMINI_API_KEY ? 'Present' : 'Missing');

        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

        console.log('\nSending test request...');
        const result = await model.generateContent('Say "Hello, testing connection!"');
        const response = await result.response;
        const text = response.text();

        console.log('\nResponse received:', text);
        console.log('\nConnection test successful! ✅');
        return true;
    } catch (error) {
        console.error('\nConnection test failed! ❌');
        console.error('Error details:', error);
        
        if (error.message.includes('API_KEY_INVALID')) {
            console.log('\nThe API key appears to be invalid. Please:');
            console.log('1. Go to https://makersuite.google.com/app/apikey');
            console.log('2. Create a new API key');
            console.log('3. Update your .env file with the new key');
        } else if (error.message.includes('NOT_FOUND') || error.message.includes('404')) {
            console.log('\nThe model was not found. This could be because:');
            console.log('1. The model name has changed (currently using gemini-1.5-pro)');
            console.log('2. Your API key does not have access to this model');
            console.log('3. There might be a service disruption');
            console.log('\nPlease check the available models at: https://ai.google.dev/models');
        }
        return false;
    }
}

testGeminiConnection(); 