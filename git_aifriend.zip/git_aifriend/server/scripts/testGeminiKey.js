const dotenv = require('dotenv');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');

dotenv.config({ path: path.join(__dirname, '../../.env') });

async function testGeminiKey() {
    console.log('\nTesting Gemini API Key');
    console.log('====================');
    
    const apiKey = process.env.GEMINI_API_KEY;
    console.log('API Key:', apiKey ? `${apiKey.substring(0, 8)}...${apiKey.substring(apiKey.length - 4)}` : 'Not found');

    try {
        console.log('\nInitializing Gemini AI...');
        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

        console.log('Sending test request...');
        const result = await model.generateContent('Say "Hello, testing connection!"');
        const response = await result.response;
        const text = response.text();

        console.log('\nResponse received:', text);
        console.log('\n✅ API key is valid and working!');
        return true;
    } catch (error) {
        console.error('\n❌ API key test failed!');
        console.error('Error details:', error.message);
        
        if (error.message.includes('API_KEY_INVALID')) {
            console.log('\nPlease follow these steps:');
            console.log('1. Go to https://makersuite.google.com/app/apikey');
            console.log('2. Make sure you have enabled the Gemini API');
            console.log('3. Create a new API key');
            console.log('4. Update your .env file with the new key');
        }
        return false;
    }
}

// Run the test
testGeminiKey().then(success => {
    process.exit(success ? 0 : 1);
}); 