const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');
const bcrypt = require('bcryptjs');

dotenv.config();

async function verifyTestUser() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        // First, delete any existing test user
        await User.deleteOne({ email: 'test@example.com' });
        console.log('Cleaned up existing test user');

        // Create a new test user with a known password
        const plainPassword = 'password123';
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(plainPassword, salt);

        const testUser = new User({
            firstName: 'Test',
            lastName: 'User',
            email: 'test@example.com',
            password: hashedPassword,
            age: 25,
            aiName: 'Friend'
        });

        await testUser.save();
        console.log('Created new test user');

        // Verify the user was created
        const savedUser = await User.findOne({ email: 'test@example.com' }).select('+password');
        console.log('\nSaved user details:', {
            email: savedUser.email,
            hashedPassword: savedUser.password,
            firstName: savedUser.firstName
        });

        // Test password comparison
        const isMatch = await bcrypt.compare(plainPassword, savedUser.password);
        console.log('\nPassword verification:', {
            plainPassword,
            isMatch
        });

        // Test the comparePassword method
        const methodMatch = await savedUser.comparePassword(plainPassword);
        console.log('\ncomparePassword method test:', {
            plainPassword,
            methodMatch
        });

        mongoose.connection.close();
        console.log('\nVerification complete');
    } catch (error) {
        console.error('Verification error:', error);
        mongoose.connection.close();
    }
}

verifyTestUser(); 