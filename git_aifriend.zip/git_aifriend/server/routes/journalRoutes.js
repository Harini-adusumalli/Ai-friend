const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Journal = require('../models/Journal');
const geminiService = require('../services/GeminiService');

// Create journal entry
router.post('/', auth, async (req, res) => {
    try {
        const { content } = req.body;
        
        if (!content) {
            return res.status(400).json({ message: 'Content is required' });
        }

        // Create and save journal entry first
        const journal = new Journal({
            user: req.user.userId,
            content,
            aiAnalysis: 'AI analysis in progress...' // Initial state
        });

        await journal.save();
        console.log('Journal entry created:', journal._id);

        // Get AI analysis asynchronously
        try {
            const aiAnalysis = await geminiService.analyzeJournalEntry(content);
            
            // Update journal with AI analysis
            if (aiAnalysis && !aiAnalysis.includes('unavailable')) {
                journal.aiAnalysis = aiAnalysis;
                await journal.save();
                console.log('AI analysis added to journal entry');
            } else {
                // Retry once if first attempt failed
                const retryAnalysis = await geminiService.analyzeJournalEntry(content);
                journal.aiAnalysis = retryAnalysis;
                await journal.save();
                console.log('AI analysis added on retry');
            }
        } catch (error) {
            console.error('Failed to get AI analysis:', error);
            journal.aiAnalysis = 'AI insights temporarily unavailable. Please check back later.';
            await journal.save();
        }

        res.status(201).json(journal);
    } catch (error) {
        console.error('Error creating journal entry:', error);
        res.status(500).json({ 
            message: 'Error creating journal entry',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Get user's journal entries
router.get('/', auth, async (req, res) => {
    try {
        const entries = await Journal.find({ user: req.user.userId })
            .sort({ createdAt: -1 });
        res.json(entries);
    } catch (error) {
        console.error('Error fetching journal entries:', error);
        res.status(500).json({ message: 'Error fetching journal entries' });
    }
});

// Update journal entry
router.patch('/:id', auth, async (req, res) => {
    try {
        const { content, mood } = req.body;
        const journal = await Journal.findOneAndUpdate(
            { _id: req.params.id, user: req.user.userId },
            { content, mood },
            { new: true }
        );
        
        if (!journal) {
            return res.status(404).json({ message: 'Journal entry not found' });
        }
        
        res.json(journal);
    } catch (error) {
        res.status(500).json({ message: 'Error updating journal entry', error: error.message });
    }
});

// Delete journal entry
router.delete('/:id', auth, async (req, res) => {
    try {
        const journal = await Journal.findOneAndDelete({
            _id: req.params.id,
            user: req.user.userId
        });
        
        if (!journal) {
            return res.status(404).json({ message: 'Journal entry not found' });
        }
        
        res.json({ message: 'Journal entry deleted' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting journal entry', error: error.message });
    }
});

module.exports = router; 