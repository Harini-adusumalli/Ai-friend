const express = require('express');
const router = express.Router();
const Mood = require('../models/Mood');
const auth = require('../middleware/auth');

// Add new mood entry
router.post('/add', auth, async (req, res) => {
    try {
        const { mood, value, notes } = req.body;
        
        // Validate input
        if (!mood || !value) {
            return res.status(400).json({ message: 'Mood and value are required' });
        }

        // Validate value range
        if (value < 1 || value > 5) {
            return res.status(400).json({ message: 'Value must be between 1 and 5' });
        }

        const newMood = new Mood({
            user: req.user.userId,
            mood,
            value,
            notes: notes || '',
            createdAt: new Date()
        });

        await newMood.save();
        
        // Log successful save
        console.log('Mood saved:', {
            user: req.user.userId,
            mood,
            value
        });

        res.status(201).json(newMood);
    } catch (error) {
        console.error('Error adding mood:', error);
        res.status(500).json({ 
            message: 'Error recording mood',
            error: error.message 
        });
    }
});

// Get mood history
router.get('/history', auth, async (req, res) => {
    try {
        console.log('Fetching mood history for user:', req.user.userId); // Debug log
        
        const moods = await Mood.find({ user: req.user.userId })
            .sort({ createdAt: -1 })
            .limit(30);
            
        console.log('Found moods:', moods.length); // Debug log
        res.json(moods);
    } catch (error) {
        console.error('Error fetching mood history:', error);
        res.status(500).json({ 
            message: 'Error fetching mood history',
            error: error.message 
        });
    }
});

module.exports = router;