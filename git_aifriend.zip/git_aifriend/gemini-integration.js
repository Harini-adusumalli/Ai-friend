class GeminiAI {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.fallbackMode = false;
        
        // Check if API key is valid
        if (!apiKey || !this.isValidApiKeyFormat(apiKey)) {
            console.warn('Invalid or missing Gemini API key, operating in fallback mode');
            this.fallbackMode = true;
        }
    }
    
    // Check if key format is valid
    isValidApiKeyFormat(key) {
        return typeof key === 'string' && /^AIza[A-Za-z0-9_-]{35}$/.test(key);
    }

    // Mood Analysis
    async analyzeMood(moodData, notes) {
        const prompt = `Analyze the following mood data and notes to provide personalized support:
            Mood: ${moodData}
            Notes: ${notes}`;
        return await this.generateResponse(prompt);
    }

    // Journal Analysis
    async analyzeJournalEntry(entry) {
        const prompt = `Analyze this journal entry and provide supportive insights:
            Entry: ${entry}`;
        return await this.generateResponse(prompt);
    }

    // Goal Planning Assistant
    async suggestGoalSteps(goal) {
        const prompt = `Help break down this goal into actionable steps:
            Goal: ${goal}`;
        return await this.generateResponse(prompt);
    }

    // Meditation Guide
    async generateMeditationScript(duration, type) {
        const prompt = `Create a gentle meditation script for:
            Duration: ${duration} minutes
            Type: ${type}`;
        return await this.generateResponse(prompt);
    }

    // Resource Recommendations
    async getResourceRecommendations(userState) {
        const prompt = `Suggest personalized mental health resources based on:
            Current State: ${userState}`;
        return await this.generateResponse(prompt);
    }

    // Main Gemini API call
    async generateResponse(prompt, conversationHistory = null) {
        // Use fallback mode immediately if needed
        if (this.fallbackMode) {
            return this.generateFallbackResponse(prompt);
        }
        
        try {
            let requestBody;
            
            // Format request differently based on whether we have conversation history
            if (conversationHistory && Array.isArray(conversationHistory) && conversationHistory.length > 0) {
                // For chat-like conversations with history
                requestBody = {
                    contents: conversationHistory,
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 1024,
                    }
                };
            } else {
                // For single-turn prompts
                requestBody = {
                    contents: [{
                        parts: [{
                            text: prompt
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 1024,
                    }
                };
            }

            // Get model name from config if available
            const modelName = (typeof geminiConfig !== 'undefined' && geminiConfig.modelName) 
                ? geminiConfig.modelName 
                : 'gemini-1.5-pro';

            const response = await fetch(`https://generativelanguage.googleapis.com/v1/models/${modelName}:generateContent?key=${this.apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error('Gemini API error response:', errorData);
                
                // Check for specific error types and handle accordingly
                if (errorData.error) {
                    // If we get a model not found error, try with fallback model
                    if (errorData.error.code === 404 || errorData.error.status === 'NOT_FOUND') {
                        console.log('Model not found, trying with fallback model gemini-pro');
                        
                        // Try with the older model as a fallback
                        const fallbackResponse = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${this.apiKey}`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(requestBody)
                        });
                        
                        if (!fallbackResponse.ok) {
                            this.fallbackMode = true;
                            return this.generateFallbackResponse(prompt);
                        }
                        
                        const fallbackData = await fallbackResponse.json();
                        if (!fallbackData.candidates || !fallbackData.candidates[0] || !fallbackData.candidates[0].content) {
                            this.fallbackMode = true;
                            return this.generateFallbackResponse(prompt);
                        }
                        
                        return fallbackData.candidates[0].content.parts[0].text;
                    }
                    
                    // Rate limiting or quota exceeded
                    if (errorData.error.code === 429 || errorData.error.status === 'RESOURCE_EXHAUSTED') {
                        console.error('API quota exceeded or rate limited');
                        this.fallbackMode = true;
                        return this.generateFallbackResponse(prompt, true);
                    }
                }
                
                throw new Error(`API call failed: ${response.status} - ${JSON.stringify(errorData)}`);
            }

            const data = await response.json();
            
            // Check if we have valid candidates
            if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts) {
                console.error('Invalid response structure:', data);
                return this.generateFallbackResponse(prompt);
            }
            
            return data.candidates[0].content.parts[0].text;
        } catch (error) {
            console.error('Error calling Gemini API:', error);
            this.fallbackMode = true;
            return this.generateFallbackResponse(prompt);
        }
    }

    // Fallback response generator with rate limit handling
    generateFallbackResponse(prompt, isRateLimited = false) {
        console.log('Using fallback response generator for prompt:', prompt);
        
        if (isRateLimited) {
            return `I apologize, but I've reached my API rate limit at the moment. Here's a simplified response:

The service is currently experiencing high demand. Please try again in a few minutes when the system has had time to recover.

In the meantime, you might want to:
- Take a few deep breaths
- Jot down your thoughts in your journal
- Try using some of the offline features of the app`;
        }
        
        if (prompt.includes('personalized support') || prompt.includes('mood data')) {
            return `I noticed you're feeling this way. Here are some suggestions:
                
1. Take a few deep breaths and practice mindfulness for 5 minutes
2. Consider a short walk outside to refresh your mind
3. Connect with a friend or family member

Remember that all emotions are temporary, and small positive actions can help shift your perspective.`;
        }
        
        if (prompt.includes('journal entry')) {
            return `Thank you for sharing your thoughts. Journaling is a powerful tool for self-reflection.

I notice you're processing your experiences thoughtfully. Consider these insights:
- Your awareness of your situation shows emotional intelligence
- Try connecting specific events with your emotional responses
- Consider what small action might help you move forward

Keep writing regularly - it's a wonderful practice for mental clarity and growth.`;
        }
        
        if (prompt.includes('goal into actionable steps')) {
            return `Here's a breakdown of your goal into manageable steps:

1. Start by clarifying exactly what success looks like for this goal
2. Break it down into 3-5 smaller milestone objectives
3. For each milestone, identify 2-3 specific actions you can take
4. Schedule these actions in your calendar
5. Track your progress and celebrate small wins along the way
6. Review and adjust your plan weekly

Remember that consistent small steps lead to significant progress over time.`;
        }
        
        if (prompt.includes('meditation script')) {
            return `Find a comfortable position where you can be relaxed but alert. Allow your eyes to gently close.

Begin by taking a few deep breaths, inhaling slowly through your nose and exhaling through your mouth. Feel the sensation of your breath as it enters and leaves your body.

Now, bring your attention to your natural breathing pattern. No need to control it - simply observe each inhale and exhale.

If your mind wanders, that's completely normal. Gently bring your focus back to your breath without judgment.

Continue breathing mindfully, allowing any tension to release with each exhale.

As we conclude this practice, slowly bring your awareness back to your surroundings. When you're ready, gently open your eyes.`;
        }
        
        // Add fallback for journal and task suggestions
        if (prompt.includes('analyze this journal entry and provide a fun') || prompt.includes('supportive AI friend')) {
            return `🌟 Thank you for sharing your thoughts! It seems like you're processing quite a bit.

📝 Here are some suggestions that might help:
- 🧘 Take 10 minutes for mindful breathing
- 📋 Break down any overwhelming tasks into smaller steps
- 🌳 Consider a short walk outside to clear your mind
- 🛌 Ensure you're getting enough rest

✨ Remember that you're doing great, and each journal entry is a step toward self-awareness and growth!`;
        }
        
        if (prompt.includes('Extract the tasks')) {
            return `🧘 Take 10 minutes for mindful breathing
📋 Break down any overwhelming tasks into smaller steps
🌳 Consider a short walk outside to clear your mind
🛌 Ensure you're getting enough rest`;
        }
        
        // Default fallback response
        return "I'm sorry, I'm currently operating with limited capabilities. Your request has been received, but I cannot provide a detailed response at this time. Please try again later when full functionality is restored.";
    }

    // Add mood analysis method
    async analyzeMoodAndSuggest(mood, notes = '') {
        const prompt = `As an AI wellness companion, analyze this mood data and provide:
        1. A brief empathetic response
        2. 2-3 personalized activity suggestions
        3. A relevant wellness tip
        
        User's mood: ${mood}
        ${notes ? `Additional context: ${notes}` : ''}
        
        Keep the total response under 150 words and format with clear sections.`;

        return await this.generateResponse(prompt);
    }
    
    // Add journal analysis method
    async analyzeJournalAndSuggestTasks(journalText) {
        const prompt = `As a supportive AI friend, analyze this journal entry and provide a fun, emoji-rich response:
        1. 🌟 A warm, understanding response to their entry (use relevant mood emojis)
        2. 📝 3-5 actionable tasks/goals based on their entry (add a fitting emoji for each task)
        3. ✨ An encouraging message with motivational emojis
        
        Journal Entry: ${journalText}
        
        Make the response friendly and engaging, using emojis to bring the suggestions to life! Keep it structured and supportive.`;

        return await this.generateResponse(prompt);
    }

    async extractTasksFromAnalysis(analysis) {
        const prompt = `Extract the tasks from this AI analysis and add fun, relevant emojis:

        Analysis: ${analysis}

        Return each task with a matching emoji at the start of the line. Make sure each task is practical and actionable.`;

        const response = await this.generateResponse(prompt);
        return response.split('\n').filter(task => task.trim());
    }
    
    // Add other analysis methods
    async analyzeSelfCareNeeds(journalEntries) {
        const prompt = `Based on these journal entries, provide personalized self-care recommendations in four categories. Format your response exactly as shown, using these exact emojis and headers:

        🫂 Emotional Wellness
        [3 specific recommendations for emotional well-being]

        💪 Physical Wellness
        [3 specific recommendations for physical health]

        🧠 Mental Wellness
        [3 specific recommendations for mental clarity]

        👥 Social Wellness
        [3 specific recommendations for social connections]

        Journal Entries: ${journalEntries}

        Make each recommendation specific, actionable, and directly related to the journal content. Use positive, encouraging language.`;

        try {
            const response = await this.generateResponse(prompt);
            return response;
        } catch (error) {
            console.error('Error generating self-care recommendations:', error);
            throw new Error('Failed to generate wellness recommendations');
        }
    }

    async generateDailyChallenge(recentMoods, completedChallenges) {
        const prompt = `Create a step-by-step self-care challenge for today, considering:
        Recent moods: ${recentMoods}
        Previously completed challenges: ${completedChallenges}

        Format the challenge as:
        1. Title with emoji
        2. Brief encouraging intro
        3. 3-4 clear, numbered steps
        4. Each step should:
           - Start with an emoji
           - Be specific and actionable
           - Take 5-15 minutes
           - Build upon previous steps
        5. End with a motivational note

        Make it:
        - Completable in one day
        - Different from previous challenges
        - Relevant to their emotional state
        - Easy to follow
        `;

        return await this.generateResponse(prompt);
    }

    async suggestTasks(journalContent = '', mood = '') {
        const prompt = `As an AI assistant, suggest 3 personalized tasks based on this journal entry and mood:

        Journal content: ${journalContent}
        Current mood: ${mood}

        Please provide:
        1. Three specific, actionable tasks that would be helpful for the user
        2. Each task should be realistic and completable today
        3. Include a brief explanation of why each task would be beneficial
        4. Use emojis to make the suggestions friendly and engaging

        Format each task like this:
        ✨ Task: [task description]
        💭 Why: [brief explanation]

        Keep the tone supportive and encouraging!`;

        try {
            const response = await this.generateResponse(prompt);
            return response;
        } catch (error) {
            console.error('Error generating task suggestions:', error);
            throw new Error('Failed to generate task suggestions');
        }
    }
}

// Export the class for ESM (import/export)
export default GeminiAI;

// For CommonJS (require)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GeminiAI;
}

// Remove the duplicate functions below since they're now part of the class
// The mood tracker class should be moved to its own file